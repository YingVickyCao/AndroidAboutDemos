package com.ssyw.exam.thirdparty;

import android.content.Context;

/**
 * 
 * @author suijun 待完善的地方： 1、AccessToken 过期提醒 2、重新认证时的判断、提示及相关的操作
 * 
 *         目前需要用户在使用当天重新认证一次
 */
public interface WeiboMethods {
	public void saveOauthV2(Context context, Object oAuth);

	public void clearOauthV2(Context context);

	public void setUpdateOauthV2Flag(boolean updateOauthV2Flag);

	public void sendOneWeibo(Context context, String content);

	public void sendOneWeibo(Context context, String content, String latitude,
			String longitude, String clientip);

	public void sendOneWeibo(Context context, String content, String pic,
			String latitude, String longitude, String clientip);

	public void sendOneWeibo(Context context, String content, String pic);
}
