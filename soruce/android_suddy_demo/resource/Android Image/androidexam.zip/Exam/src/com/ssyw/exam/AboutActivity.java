package com.ssyw.exam;

import com.ssyw.exam.utility.WindowHelper;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

public class AboutActivity extends Activity {
	
	private WindowHelper wh;
	
      @Override

	protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);// È¥µô±êÌâÀ¸
		setContentView(R.layout.activity_about);
		wh=new WindowHelper(this);
	}
      public void shotView(View view) {
  		wh.shotAndSave(wh.pic_path);
  		Intent intent = new Intent(AboutActivity.this,
  				ShareFriendActivity.class);
  		startActivity(intent);
  	}
  	public void back(View view) {
  		finish();
  	}
}
