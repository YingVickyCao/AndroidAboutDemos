package com.ssyw.exam;

import java.util.Timer;
import java.util.TimerTask;

import com.ssyw.exam.controller.MainTabController;
import com.ssyw.exam.utility.Utility;
import com.ssyw.exam.utility.WindowHelper;

import android.annotation.SuppressLint;
import android.app.ActivityGroup;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;

import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

@SuppressWarnings("deprecation")
@SuppressLint({ "NewApi", "SdCardPath" })
public class MainTabActivity extends ActivityGroup {
	private MainTabController mtc;
	private WindowHelper wh;
	private GridView gv_mainTab_bottomBar;
	private MainTabController.ImageAdapter bottomImgAdapter;
	public LinearLayout container;// 装载sub Activity的容器
	private TextView tv_main_title;
	// for exit
	private static Timer tExit;
	private static TimerTask task;
	private static Boolean isExit = false;
	private static Boolean hasTask = false;

	/** 底部按钮图片 **/
	private int[] bottombarUnselectedResId = { R.drawable.tab_main_exam_unselected,
			R.drawable.tab_main_classics_unselected,
			R.drawable.tab_main_more_unselected };

	private int[] buttomSelectedResId = { R.drawable.tab_main_exam_selected,
			R.drawable.tab_main_classics_selected,
			R.drawable.tab_main_more_selected };
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_group_main_tab);
	
		mtc = new MainTabController(this);
		wh=new WindowHelper(this);
		
		gv_mainTab_bottomBar = (GridView) this.findViewById(R.id.gv_mainTab_bottomBar);
		gv_mainTab_bottomBar.setNumColumns(bottombarUnselectedResId.length);// 设置每行列数
		gv_mainTab_bottomBar.setSelector(new ColorDrawable(Color.TRANSPARENT));// 选中的时候为透明色
		gv_mainTab_bottomBar.setGravity(Gravity.CENTER);// 位置居中
		gv_mainTab_bottomBar.setVerticalSpacing(0);// 垂直间隔
		int width = this.getWindowManager().getDefaultDisplay().getWidth()
				/ bottombarUnselectedResId.length;

		bottomImgAdapter = mtc.new ImageAdapter(this, bottombarUnselectedResId,
				width, 48, buttomSelectedResId,bottombarUnselectedResId);
		gv_mainTab_bottomBar.setAdapter(bottomImgAdapter);// 设置菜单Adapter
		gv_mainTab_bottomBar.setOnItemClickListener(new ItemClickEvent());// 项目点击事件
		container = (LinearLayout) findViewById(R.id.Container);
		tv_main_title=(TextView) findViewById(R.id.tv_main_title);
		SwitchActivity(0);// 默认打开第0页

		tExit = new Timer();
		task = new TimerTask() {
			@Override
			public void run() {
				isExit = false;
				hasTask = true;
			}
		};
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (isExit == false) {
				isExit = true;
				Utility.showToastShort(this, R.string.isExit);
				if (!hasTask) {
					tExit.schedule(task, 2000);
				} else {
					finish();
					System.exit(0);
				}
			}
		}
		return false;
	}

	public void shotView(View v){
		
		wh.shotAndSave(wh.pic_path);
		Intent intent = new Intent(MainTabActivity.this,
				ShareFriendActivity.class);
		startActivity(intent);
	}
	
	class ItemClickEvent implements OnItemClickListener {

		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			SwitchActivity(arg2);
		}
	}

	/* 根据ID打开指定的Activity */
	public void SwitchActivity(int id) {
		bottomImgAdapter.setFocus(id);// 选中项获得高亮
		container.removeAllViews();// 必须先清除容器中所有的View
		Intent intent = null;
		switch(id){
		case 0:
			intent = new Intent(MainTabActivity.this, ExamEntryActivity.class);
			break;
		case 1:
			intent = new Intent(MainTabActivity.this, ClassicsQuestion.class);
			break;
		case 2:
			intent = new Intent(MainTabActivity.this, MoreActivity.class);
			break;
		default:
			break;
		}
		tv_main_title.setText(getResources().getStringArray(R.array.main_tab_title)[id]);
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		// Activity 转为 View
		Window subActivity = getLocalActivityManager().startActivity(
				"subActivity", intent);
		// 容器添加View
		container.addView(subActivity.getDecorView(), LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT);
	}

}
