package com.ssyw.exam.model;

import java.util.ArrayList;
import java.util.Map;

import android.content.ContentValues;
import android.content.Context;

/**
 * 
 * @author sxenon 简单地修改就可以重复利用
 */
public class QuestionBankDao extends CommonDao {
	private static final String TABLE = "QuestionBank";

	public ArrayList<Map<String, Object>> getEntryList(Context context) {
		return super.getEntryList(context, TABLE);
	}

	public ArrayList<Map<String, Object>> getEntryList(Context context,
			String whereClause) {
		return super.getEntryList(context, TABLE, whereClause);
	}
	
	public ArrayList<Map<String, Object>> getEntryList(Context context,
			String whereClause,String limit) {
		return super.getEntryList(context, TABLE, whereClause, limit);
	}
	
	protected ArrayList<Integer> getIntegerList(Context context,
			String showColumn) {
		return super.getIntegerList(context, TABLE, showColumn);
	}

	protected ArrayList<Float> getFloatList(Context context, String showColumn) {
		return super.getFloatList(context, TABLE, showColumn);
	}

	protected ArrayList<String> getStringList(Context context, String showColumn) {
		return super.getStringList(context, TABLE, showColumn);
	}

	public long add(Context context, ContentValues values) {
		return super.add(context, TABLE, values);
	}

	public int update(Context context, ContentValues setValues,
			String whereClause) {
		return super.update(context, TABLE, setValues, whereClause);
	}

	public int delete(Context context, String whereClause) {
		return super.delete(context, TABLE, whereClause);

	}

	protected Map<String, Object> getEntry(Context context, String whereValues) {
		return super.getEntry(context, TABLE, whereValues);
	}
	
	protected ArrayList<Integer> getIntegerList(Context context,
			String showColumn,String whereClause){
		return super.getIntegerList(context, TABLE, showColumn, whereClause);
	}
}
