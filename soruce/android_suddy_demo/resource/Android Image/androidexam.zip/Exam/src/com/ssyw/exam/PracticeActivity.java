package com.ssyw.exam;

import com.ssyw.exam.utility.WindowHelper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

public class PracticeActivity extends Activity{
	private WindowHelper wh;
//	private ImageView iv_practice;
	private TextView practice_name;
	private TextView practice_sex;
	private SharedPreferences prference;   
	private String NAME= "PREF_NAME";  
	private String SEX= "PREF_SEX"; 
	private String KEY ="TestValue";
	private String KEY2 ="sexValue";
	String tmp;
	String asd;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	this.requestWindowFeature(Window.FEATURE_NO_TITLE);// 去掉标题栏
	setContentView(R.layout.activity_practice);
//	iv_practice=(ImageView) findViewById(R.id.iv_practice);
	practice_name=(TextView) findViewById(R.id.practice_name);
	practice_sex=(TextView) findViewById(R.id.practice_sex);
	wh=new WindowHelper(this);
	
	prference = getSharedPreferences(NAME, MODE_PRIVATE );  
	prference = getSharedPreferences(SEX, MODE_PRIVATE );  
	tmp = prference.getString(KEY, "");  
	asd=prference.getString(KEY2, "");
	practice_name.setText(tmp);  
	practice_sex.setText(asd);

	}
	public void shotView(View view) {
		wh.shotAndSave(wh.pic_path);
		Intent intent = new Intent(PracticeActivity.this,
				ShareFriendActivity.class);
		startActivity(intent);
	}
	public void back(View view) {
		finish();
	}
}
