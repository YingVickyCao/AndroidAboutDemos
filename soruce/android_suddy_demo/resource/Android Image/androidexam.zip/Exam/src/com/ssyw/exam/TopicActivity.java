package com.ssyw.exam;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.ssyw.exam.controller.TopicController;
import com.ssyw.exam.utility.Utility;
import com.ssyw.exam.utility.WindowHelper;
import com.ssyw.exam.widget.ScrollLayout;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Toast;

@SuppressLint("UseSparseArrays")
public class TopicActivity extends Activity {
	static final int EXPLAIN_ID = 5000;
	static final int RG_TOPIC_ID = 10000;
	// 定义滑动框
	private ScrollLayout sLayout;
	private WindowHelper wh;
	// 初始化题库服务
	TopicController topicController = new TopicController();
	private int topicType;

	private TextView tv_topic_title;
	private Chronometer ch_topic_text;
	ArrayList<Map<String, Object>> topicList;
	HashMap<Integer, HashMap<String, Integer>> totalTopicItemsMap;
	HashMap<Integer, Integer> selectMap;
	// for seek
	private PopupWindow seekPopupWindow;
	private ImageButton btn_seek;
	private View seekView;
	private ImageButton ib_seek_ok;
	private ImageButton ib_seek_cancel;
	private SeekBar sb_seek;
	private TextView tv_progress;
	private int nowTopic;
	private int totalTopic;
	private int newTopic;

	private int textWrongTopic;
	private int textRightTopic;
	// 查看答案按钮转换开关
	boolean lookAnswerSw = true;

	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 去掉标题栏
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		topicType = getIntent().getExtras().getInt("type");
		if (topicType != 5) {
			setContentView(R.layout.activity_topic);
		} else {
			setContentView(R.layout.activity_text);
		}
		totalTopicItemsMap = new HashMap<Integer, HashMap<String, Integer>>();
		wh = new WindowHelper(this);
		selectMap = new HashMap<Integer, Integer>();
		sLayout = (ScrollLayout) findViewById(R.id.scrollLayout);
		tv_topic_title = (TextView) findViewById(R.id.tv_topic_title);

		topicList = new ArrayList<Map<String, Object>>();
		// 根据测试方式，获得题库:1-顺序；2-随机；3-章节；4-强化；5-测试；6-错题本；7-我的收藏

		switch (topicType) {
		case 1: {
			tv_topic_title.setText(getResources().getString(
					R.string.sequence_practice));
			topicList = topicController.sequentialSearch(TopicActivity.this);
			break;
		}
		case 2: {
			tv_topic_title.setText(getResources().getString(
					R.string.random_practice));
			topicList = topicController.randomSearch(TopicActivity.this);
			topicController.initDaoIdMap(topicType);
			break;
		}
		case 5: {
			tv_topic_title.setText(getResources().getString(
					R.string.practice_test));
			topicList = topicController.textSearch(TopicActivity.this);
			topicController.initDaoIdMap(topicType);
			ch_topic_text = (Chronometer) findViewById(R.id.ch_topic_text);
			ch_topic_text.start();
			textWrongTopic = 0;
			textRightTopic = 0;
			break;
		}
		case 6: {
			tv_topic_title.setText(getResources().getString(
					R.string.title_errorbook));
			topicList = topicController.errorBookSearch(TopicActivity.this);
			topicController.initDaoIdMap(topicType);
			break;
		}
		case 7: {
			tv_topic_title.setText(getResources().getString(
					R.string.myselection));
			topicList = topicController.collectedSearch(TopicActivity.this);
			topicController.initDaoIdMap(topicType);
			break;
		}
		default:
			break;
		}
		// 生成界面
		ScrollView tempLayout = new ScrollView(TopicActivity.this);
		int count = 1;
		for (Map<String, Object> map : topicList) {
			tempLayout = createTopic(TopicActivity.this, count, map);
			sLayout.addView(tempLayout, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			count++;
		}
		if (topicType == 1) {
			this.dataLoad();
			this.setCollectButton();
		} else {
			if (!topicController.isDataIdMapNull()) {
				this.setCollectButton();
			} else {
				showToast(getResources().getString(R.string.data_not_exist));
				finish();
			}
		}
		// for seek
		btn_seek = (ImageButton) findViewById(R.id.btn_seek);
		seekView = getLayoutInflater()
				.inflate(R.layout.popup_window_seek, null);
		seekPopupWindow = new PopupWindow(seekView, LayoutParams.MATCH_PARENT,
				LayoutParams.WRAP_CONTENT);

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (topicType != 5) {
			this.dataSave();
			return super.onKeyDown(keyCode, event);
		} else {
			this.exitExam();
			return false;
		}
	}

	// 根据测试方式和题目类型，生成页面
	@SuppressWarnings("deprecation")
	public ScrollView createTopic(final Context context, int count,
			final Map<String, Object> tempMap) {
		ScrollView scrollView = new ScrollView(context);
		final LinearLayout topicLayout = new LinearLayout(context);
		topicLayout.setOrientation(LinearLayout.VERTICAL);
		// 题目生成
		final TextView tv_topic = new TextView(context);
		tv_topic.setTextSize(24);
		tv_topic.setText(String.valueOf(count) + "."
				+ String.valueOf(tempMap.get("question")));
		topicLayout.addView(tv_topic, new LinearLayout.LayoutParams(
				LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		final LinearLayout explainLayout = new LinearLayout(context);
		explainLayout.setId(count + EXPLAIN_ID);
		// 根据题型形成选项
		switch (Integer.valueOf(String.valueOf(tempMap.get("type")))) {
		// 选择题
		case 1: {
			final HashMap<String, Integer> orderMap = topicController
					.getOrderMap(1);
			totalTopicItemsMap.put(count, orderMap);
			final RadioGroup rg_topic = new RadioGroup(context);
			rg_topic.setId(count + RG_TOPIC_ID);
			final RadioButton rb_item1 = new RadioButton(context);
			rb_item1.setText("A."
					+ String.valueOf(tempMap.get(topicController
							.getItemValue(orderMap.get("A")))));
			final RadioButton rb_item2 = new RadioButton(context);
			rb_item2.setText("B."
					+ String.valueOf(tempMap.get(topicController
							.getItemValue(orderMap.get("B")))));
			final RadioButton rb_item3 = new RadioButton(context);
			rb_item3.setText("C."
					+ String.valueOf(tempMap.get(topicController
							.getItemValue(orderMap.get("C")))));
			final RadioButton rb_item4 = new RadioButton(context);
			rb_item4.setText("D."
					+ String.valueOf(tempMap.get(topicController
							.getItemValue(orderMap.get("D")))));
			// 添加单选按钮
			rg_topic.addView(rb_item1, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			rg_topic.addView(rb_item2, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			rg_topic.addView(rb_item3, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			rg_topic.addView(rb_item4, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			// 单选框绑定事件
			rg_topic.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(RadioGroup group, int checkedId) {
					selectMap.put(sLayout.getCurScreen(), 1);
					RadioButton tempRb = (RadioButton) findViewById(checkedId);
					String tempString = tempRb.getText().toString();
					tempString = tempString.substring(0,
							tempString.indexOf("."));
					// 选择正确时处理
					if (String.valueOf(orderMap.get(tempString)).equals(
							tempMap.get("answer"))) {
						topicController.setRadioButtonState(rg_topic, false);
						topicController.addRightCount(context, topicController
								.getDaoId(context, topicType,
										sLayout.getCurScreen() + 1));
						tempRb.setTextColor(Color.GREEN);
						sLayout.snapToScreen(sLayout.getCurScreen() + 1);
						if (topicType == 5) {
							textRightTopic++;
						}
					}
					// 选择错误时处理
					else {
						// 比较选项和正确答案
						topicController.setRadioButtonState(rg_topic, false);
						topicController.addWrongCount(context, topicController
								.getDaoId(context, topicType,
										sLayout.getCurScreen() + 1));
						if (topicType == 5) {
							textWrongTopic++;
							tempRb.setTextColor(Color.GREEN);
							sLayout.snapToScreen(sLayout.getCurScreen() + 1);
						} else {
							tempRb.setTextColor(Color.RED);
							topicController.getCorrectRadioButton(context,
									rg_topic, orderMap,
									(String) tempMap.get("answer"))
									.setTextColor(Color.GREEN);
							explainLayout.setVisibility(LinearLayout.VISIBLE);
						}
					}
				}
			});

			topicLayout.addView(rg_topic, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			break;
		}
		// 判断题
		case 2: {
			final HashMap<String, Integer> orderMap = topicController
					.getOrderMap(2);
			totalTopicItemsMap.put(count, orderMap);
			final RadioGroup rg_topic = new RadioGroup(context);
			rg_topic.setId(count + RG_TOPIC_ID);
			final RadioButton rb_item1 = new RadioButton(context);
			rb_item1.setText("A."
					+ String.valueOf(tempMap.get(topicController
							.getItemValue(orderMap.get("A")))));
			final RadioButton rb_item2 = new RadioButton(context);
			rb_item2.setText("B."
					+ String.valueOf(tempMap.get(topicController
							.getItemValue(orderMap.get("B")))));
			// 添加单选按钮
			rg_topic.addView(rb_item1, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			rg_topic.addView(rb_item2, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			// 单选框绑定事件
			rg_topic.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(RadioGroup group, int checkedId) {
					selectMap.put(sLayout.getCurScreen(), 1);
					RadioButton tempRb = (RadioButton) findViewById(checkedId);
					String tempString = tempRb.getText().toString();
					tempString = tempString.substring(0,
							tempString.indexOf("."));
					// 选择正确时处理
					if (String.valueOf(orderMap.get(tempString)).equals(
							tempMap.get("answer"))) {
						topicController.setRadioButtonState(rg_topic, false);
						topicController.addRightCount(context, topicController
								.getDaoId(context, topicType,
										sLayout.getCurScreen() + 1));
						tempRb.setTextColor(Color.GREEN);
						sLayout.snapToScreen(sLayout.getCurScreen() + 1);
						if (topicType == 5) {
							textRightTopic++;
						}
					}
					// 选择错误时处理
					else {
						// 比较选项和正确答案
						topicController.setRadioButtonState(rg_topic, false);
						topicController.addWrongCount(context, topicController
								.getDaoId(context, topicType,
										sLayout.getCurScreen() + 1));
						if (topicType == 5) {
							textWrongTopic++;
							tempRb.setTextColor(Color.GREEN);
							sLayout.snapToScreen(sLayout.getCurScreen() + 1);
						} else {
							tempRb.setTextColor(Color.RED);
							topicController.getCorrectRadioButton(context,
									rg_topic, orderMap,
									(String) tempMap.get("answer"))
									.setTextColor(Color.GREEN);
							explainLayout.setVisibility(LinearLayout.VISIBLE);
						}
					}
				}
			});

			topicLayout.addView(rg_topic, new LinearLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			break;
		}
		default:
			break;
		}

		TextView tv_explain = new TextView(context);
		tv_explain.setText(String.valueOf(tempMap.get("explain")));
		explainLayout.addView(tv_explain, new LinearLayout.LayoutParams(
				LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		explainLayout.setVisibility(LinearLayout.INVISIBLE);
		topicLayout.addView(explainLayout, new LinearLayout.LayoutParams(
				LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		scrollView.addView(topicLayout, new LinearLayout.LayoutParams(
				LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		return scrollView;
	}

	public void toPreviousQuestion(View view) {
		int curScreen = sLayout.getCurScreen();
		if (curScreen == 0) {
			Utility.showToastShort(this, R.string.topic_first_question);
		} else {
			sLayout.snapToScreen(curScreen - 1);
		}
		this.setCollectButton();

	}

	public void toNextQuestion(View view) {
		int curScreen = sLayout.getCurScreen();
		if (curScreen == topicList.size() - 1) {
			Utility.showToastShort(this, R.string.topic_last_question);
		} else {
			sLayout.snapToScreen(curScreen + 1);
		}
		this.setCollectButton();
	}

	public void backToMainActivity(View view) {
		if (topicType != 5) {
			this.dataSave();
			finish();
		} else {
			this.exitExam();
		}
	}

	public void toLookAnswer(View v) {
		Button btn_look_answer = (Button) findViewById(R.id.btn_look_answer);
		if (lookAnswerSw) {
			btn_look_answer.setText(getResources().getString(
					R.string.topic_answermode));
			lookAnswerSw = false;
			// 整体切换
			for (int i = 0; i < sLayout.getChildCount(); i++) {
				LinearLayout explainLayout = (LinearLayout) sLayout.getChildAt(
						i).findViewById(EXPLAIN_ID + i + 1);
				explainLayout.setVisibility(LinearLayout.VISIBLE);
				// 判断此题是否回答过
				if (!selectMap.containsKey(i)) {
					RadioGroup rg_topic = (RadioGroup) sLayout.getChildAt(i)
							.findViewById(RG_TOPIC_ID + i + 1);
					String answer = topicController.getAnswer(
							TopicActivity.this, topicController.getDaoId(
									TopicActivity.this, topicType, i + 1));
					topicController.getCorrectRadioButton(TopicActivity.this,
							rg_topic, totalTopicItemsMap.get(i + 1), answer)
							.setTextColor(Color.GREEN);
					topicController.setRadioButtonState(rg_topic, false);
				}
			}
		} else {
			btn_look_answer.setText(getResources().getString(
					R.string.topic_lookanswer));
			lookAnswerSw = true;
			// 整体切换
			for (int i = 0; i < sLayout.getChildCount(); i++) {
				LinearLayout explainLayout = (LinearLayout) sLayout.getChildAt(
						i).findViewById(EXPLAIN_ID + i + 1);
				// 判断此题是否回答过
				if (!selectMap.containsKey(i)) {
					explainLayout.setVisibility(LinearLayout.INVISIBLE);
					RadioGroup rg_topic = (RadioGroup) sLayout.getChildAt(i)
							.findViewById(RG_TOPIC_ID + i + 1);
					String answer = topicController.getAnswer(
							TopicActivity.this, topicController.getDaoId(
									TopicActivity.this, topicType, i + 1));
					topicController.getCorrectRadioButton(TopicActivity.this,
							rg_topic, totalTopicItemsMap.get(i + 1), answer)
							.setTextColor(Color.BLACK);
					topicController.setRadioButtonState(rg_topic, true);
				}
			}
		}
	}

	public void shotView(View view) {
		wh.shotAndSave(wh.pic_path);
		Intent intent = new Intent(TopicActivity.this,
				ShareFriendActivity.class);
		startActivity(intent);
	}

	public void toCollect(View v) {
		int flag = topicController.getCollectedFlag(
				TopicActivity.this,
				topicController.getDaoId(TopicActivity.this, topicType,
						sLayout.getCurScreen() + 1));
		if (flag == 1) {
			topicController.resetCollectedFlag(TopicActivity.this,
					topicController.getDaoId(TopicActivity.this, topicType,
							sLayout.getCurScreen() + 1));
			this.setCollectButton();
		} else {
			topicController.setCollectedFlag(TopicActivity.this,
					topicController.getDaoId(TopicActivity.this, topicType,
							sLayout.getCurScreen() + 1));
			this.setCollectButton();
		}
	}

	String topic_seek;

	public void toSeek(View v) {
		if (seekPopupWindow.isShowing()) {
			return;
		}
		nowTopic = sLayout.getCurScreen() + 1;
		totalTopic = topicList.size();
		Point size = wh.getDefaultDisplaySize();
		seekPopupWindow.showAtLocation(btn_seek, Gravity.BOTTOM, 0,
				size.x * 45 / 320);
		ib_seek_ok = (ImageButton) seekView.findViewById(R.id.ib_seek_ok);
		ib_seek_cancel = (ImageButton) seekView
				.findViewById(R.id.ib_seek_cancel);
		sb_seek = (SeekBar) seekView.findViewById(R.id.sb_seek);
		tv_progress = (TextView) seekView.findViewById(R.id.tv_progress);
		topic_seek = getString(R.string.topic_seek);
		
		tv_progress.setText(topic_seek + "     " + nowTopic + "/" + totalTopic);
		sb_seek.setMax(totalTopic - 1);
		sb_seek.setProgress(nowTopic - 1);
		sb_seek.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				sLayout.setToScreen(newTopic - 1);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
			}

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				// TODO Auto-generated method stub
				newTopic = seekBar.getProgress() + 1;
				tv_progress.setText(topic_seek + "     " + newTopic + "/"
						+ totalTopic);
			}
		});
		ib_seek_ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				seekPopupWindow.dismiss();
			}
		});
		ib_seek_cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				sLayout.setToScreen(nowTopic - 1);
				seekPopupWindow.dismiss();
			}
		});
	}

	public void submitAnswer(View v) {
		this.exitExam();
	}

	protected void exitExam() {
		new AlertDialog.Builder(TopicActivity.this)
				.setTitle(getResources().getString(R.string.topic_exit_exam))
				.setNegativeButton(getResources().getString(R.string.ok),
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
								String useTime = ch_topic_text.getText()
										.toString();
								int totalCount = textRightTopic
										+ textWrongTopic;
								int totalScore = textRightTopic * 2;
								Calendar c = Calendar.getInstance();
								String dateTime = c.get(Calendar.YEAR) + "-"
										+ c.get(Calendar.MONTH) + "-"
										+ c.get(Calendar.DAY_OF_MONTH);
								topicController.addTestScore(
										TopicActivity.this, totalScore,
										textRightTopic, textWrongTopic,
										totalCount, dateTime, useTime);
								Intent intent = new Intent(TopicActivity.this,
										DetailsRecordActivity.class);
								intent.putExtra("examResult",
										topicController.getThisTestScore());
								intent.putExtra("MODE", 1);
								startActivity(intent);
								finish();
							}
						})
				.setPositiveButton(getResources().getString(R.string.cancel),
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
							}
						}).show();
	}

	// 获取当前题目是否收藏过
	protected void setCollectButton() {
		Button btn_collect = (Button) findViewById(R.id.btn_topic_collect);
		int flag = topicController.getCollectedFlag(
				TopicActivity.this,
				topicController.getDaoId(TopicActivity.this, topicType,
						sLayout.getCurScreen() + 1));
		if (flag == 1) {
			btn_collect.setText(getResources().getString(
					R.string.topic_collect_cancel));
		} else {
			btn_collect.setText(getResources()
					.getString(R.string.topic_collect));
		}
	}

	protected void dataSave() {
		SharedPreferences settings = getSharedPreferences("LocationAt",
				Activity.MODE_PRIVATE);
		SharedPreferences.Editor editor = settings.edit();
		String name = this.getIntent().getStringExtra("EXEC_MODE");
		editor.putInt(name, sLayout.getCurScreen());
		editor.commit();
	}

	protected void dataLoad() {
		SharedPreferences settings = getSharedPreferences("LocationAt",
				Activity.MODE_PRIVATE);
		String name = this.getIntent().getStringExtra("EXEC_MODE");
		int viewNumber = settings.getInt(name, 0);
		sLayout.setToScreen(viewNumber);
	}

	protected void showToast(String st) {
		Toast.makeText(TopicActivity.this, st, Toast.LENGTH_SHORT).show();
	}
}
