package com.ssyw.exam;

import com.ssyw.exam.controller.StatisticsController;
import com.ssyw.exam.utility.WindowHelper;
import com.ssyw.exam.widget.PieChartView;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;

public class StatisticsTopic extends Activity {
	private float data[];
	private WindowHelper wh;
	private StatisticsController statisticsController = new StatisticsController();
	private PieChartView pcv_statistics;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tap_statistics);
		
		wh=new WindowHelper(this);
		
		pcv_statistics=(PieChartView) findViewById(R.id.pcv_statistics);
		pcv_statistics.setDataCount(5);
		pcv_statistics.setColor(new int[] { Color.YELLOW, Color.BLUE, Color.GRAY,
				Color.MAGENTA, Color.RED });
		data = new float[5];
		data[0] = statisticsController.getUndoQuestionNum(this);
		data[1] = statisticsController.getRightAlwaysQuestionNum(this);
		data[2] = statisticsController.getRightOftenQuestionNum(this);
		data[3] = statisticsController.getWrongAlwaysQuestionNum(this);
		data[4] = statisticsController.getWrongOftenQuestionNum(this);
		pcv_statistics.setData(data);
		pcv_statistics.setDataTitle(getResources().getStringArray(
				R.array.statistics_status));
		
		//setDefaultSize	
		Point size = wh.getDefaultDisplaySize();
		if(Math.min(size.x, size.y)<=300){
			size.x=size.x*7/5;
		}else{
			size.x=size.x*6/5;	
		}
		pcv_statistics.setDefaultSize(size);
		
		pcv_statistics.setPadding(15, 0, 15, 0);
	}
}
