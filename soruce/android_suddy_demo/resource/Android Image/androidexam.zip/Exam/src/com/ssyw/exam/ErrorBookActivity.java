package com.ssyw.exam;

import java.util.ArrayList;
import java.util.Map;
import com.ssyw.exam.model.QuestionBankService;
import com.ssyw.exam.utility.WindowHelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class ErrorBookActivity extends Activity {
	private WindowHelper wh;
	private ListView listView_errorbook;
	Button btn_clear_error;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);// 去掉标题栏
		setContentView(R.layout.activity_errorbook);
		wh = new WindowHelper(this);
		listView_errorbook = (ListView) findViewById(R.id.listView_errorbook);
		btn_clear_error = (Button) findViewById(R.id.btn_clear_error);
		// listview
		QuestionBankService questionBank = new QuestionBankService();
		final ArrayList<Map<String, Object>> getEntryList = questionBank
				.getErrorEntryList(this);
		final SimpleAdapter simpleAdapter = new SimpleAdapter(this,
				getEntryList, R.layout.list_errorbookmenu, new String[] {
						"_id", "question" }, new int[] { R.id.list_error_id,
						R.id.list_error_name });
		listView_errorbook.setAdapter(simpleAdapter);
		simpleAdapter.notifyDataSetChanged();
		// btn_clear_error
		btn_clear_error.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {

			}
		});
		// listView_errorbook长按删除
		listView_errorbook
				.setOnItemLongClickListener(new OnItemLongClickListener() {

					@Override
					public boolean onItemLongClick(AdapterView<?> parent,
							View view, int position, long id) {
						new AlertDialog.Builder(ErrorBookActivity.this)
								.setTitle(getString(R.string.error_title))
								.setMessage(getString(R.string.error_message))
								.setPositiveButton(
										getString(R.string.btn_sure_error),
										new DialogInterface.OnClickListener() {
											@Override
											public void onClick(
													DialogInterface parent,
													int position) {
												int size = getEntryList.size();
												if (size > 0) {
													getEntryList
															.remove(getEntryList
																	.size() - 1);

													simpleAdapter
															.notifyDataSetChanged();
												}

											}
										})
								.setNegativeButton(
										getString(R.string.btn_cancel_error),
										new DialogInterface.OnClickListener() {

											@Override
											public void onClick(
													DialogInterface arg0,
													int arg1) {

											}
										}).show();
						return false;
					}
				});
	}

	public void shotView(View view) {
		wh.shotAndSave(wh.pic_path);
		Intent intent = new Intent(ErrorBookActivity.this,
				ShareFriendActivity.class);
		startActivity(intent);
	}

	public void back(View view) {
		finish();
	}
}
