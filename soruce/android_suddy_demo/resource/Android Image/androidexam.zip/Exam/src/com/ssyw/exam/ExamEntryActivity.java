package com.ssyw.exam;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.Toast;

@SuppressLint("NewApi")
public class ExamEntryActivity extends Activity {
	private ImageButton  btn_sequence, btn_random, btn_chapters_and_sections,
			btn_errorbook, btn_intensify_practice, btn_practice_test,
			btn_record, btn_collect,btn_statistics;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_exam_entry);
		// findViewById
		btn_sequence = (ImageButton) findViewById(R.id.btn_sequence);
		btn_random = (ImageButton) findViewById(R.id.btn_random);
		btn_chapters_and_sections = (ImageButton) findViewById(R.id.btn_chapters_and_sections);
		btn_errorbook = (ImageButton) findViewById(R.id.btn_errorbook);
		btn_intensify_practice = (ImageButton) findViewById(R.id.btn_intensify_practice);
		btn_practice_test = (ImageButton) findViewById(R.id.btn_practice_test);
		btn_record = (ImageButton) findViewById(R.id.btn_record);
		btn_collect = (ImageButton) findViewById(R.id.btn_collect);
		btn_statistics=(ImageButton) findViewById(R.id.btn_statistics);
		// btn_sequence
		btn_sequence.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent aIntent = new Intent(ExamEntryActivity.this,
						TopicActivity.class);
				aIntent.putExtra("type", 1);
				aIntent.putExtra("EXEC_MODE", getResources().getString(R.string.sequence_practice));
				startActivity(aIntent);
			}
		});

		// btn_random
		btn_random.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent bIntent = new Intent(ExamEntryActivity.this,
						TopicActivity.class);
				bIntent.putExtra("type", 2);
				bIntent.putExtra("EXEC_MODE", getResources().getString(R.string.random_practice));
				startActivity(bIntent);
			}
		});

		// btn_chapters_and_sections
		btn_chapters_and_sections.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showToast(getResources().getString(R.string.please_wait));
			}
		});

		// btn_intensify_practice
		btn_intensify_practice.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showToast(getResources().getString(R.string.please_wait));
			}
		});

		// btn_practice_test
		btn_practice_test.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent dIntent = new Intent(ExamEntryActivity.this,
						TopicActivity.class);
				dIntent.putExtra("type", 5);
				startActivity(dIntent);
			}
		});
		btn_statistics.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent eintent = new Intent(ExamEntryActivity.this,
						StatisticsActivity.class);
				startActivity(eintent);
			}
		});
		//btn_errorbook
		btn_errorbook.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
//				Intent fIntent=new Intent(ExamEntryActivity.this,
//						ErrorBookActivity.class);
				Intent fIntent=new Intent(ExamEntryActivity.this,
						TopicActivity.class);
				fIntent.putExtra("type", 6);
				startActivity(fIntent);
			}
		});
		//btn_record
		btn_record.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent gIntent=new Intent(ExamEntryActivity.this,
						RecordActivity.class);
				startActivity(gIntent);
			}
		});
		//btn_collect
		btn_collect.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
//				Intent gIntent=new Intent(ExamEntryActivity.this,
//						CollectActivity.class);
				Intent gIntent=new Intent(ExamEntryActivity.this,
						TopicActivity.class);
				gIntent.putExtra("type", 7);
				startActivity(gIntent);
			}
		});
	}
	protected void showToast(String st) {
		Toast.makeText(ExamEntryActivity.this, st, Toast.LENGTH_SHORT).show();
	}
}
