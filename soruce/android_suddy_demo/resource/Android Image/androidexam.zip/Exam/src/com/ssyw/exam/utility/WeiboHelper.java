package com.ssyw.exam.utility;

import com.ssyw.exam.thirdparty.SinaWeiboMethods;
import com.ssyw.exam.thirdparty.TencentWeiboMethods;
import com.ssyw.exam.thirdparty.WeiboMethods;

import android.content.Context;

/**
 * 
 * 批量处理微博
 * 
 */
public class WeiboHelper {
	private static Context mContext;
	
	public WeiboHelper(Context context){
		mContext=context;
	}
	private static WeiboMethods[] weiboArray = new WeiboMethods[] {
			new TencentWeiboMethods(), new SinaWeiboMethods(mContext) };

	public static void sendOneWeibo(Context context, String content) {
		String latitude = Utility.readSharedPreferences(context,"Location",
				"Latitude", "");
		String longitude = Utility.readSharedPreferences(context,"Location",
				"Longitude", "");
		String clientip = Utility.readSharedPreferences(context, "Location","IP",
				NetWorkHelper.DEFAULT_IP);
		for (WeiboMethods weiboMethods : weiboArray) {
			weiboMethods.sendOneWeibo(context, content,latitude,
					longitude, clientip);
		}
	}

	/**
	 * 进入应用后，首次使用微博要从文件中读出access_token 信息
	 */
	public static void setUpdateOauthV2Flag() {
		for (WeiboMethods weiboMethods : weiboArray) {
			weiboMethods.setUpdateOauthV2Flag(true);
		}
	}
}
