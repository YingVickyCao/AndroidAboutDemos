package com.ssyw.exam.model;

import java.util.ArrayList;
import java.util.Map;

import android.content.ContentValues;
import android.content.Context;

public class ExamBackupsDao extends CommonDao {
	private static final String TABLE = "ExamBackups";

	public ArrayList<Map<String, Object>> getEntryList(Context context) {
		return super.getEntryList(context, TABLE);
	}

	public ArrayList<Map<String, Object>> getEntryList(Context context,String whereClause) {
		return super.getEntryList(context, TABLE,whereClause);
	}
	
	protected ArrayList<Integer> getIntegerList(Context context,
			String showColumn) {
		return super.getIntegerList(context, TABLE, showColumn);
	}

	protected ArrayList<Float> getFloatList(Context context, String showColumn) {
		return super.getFloatList(context, TABLE, showColumn);
	}

	protected ArrayList<String> getStringList(Context context, String showColumn) {
		return super.getStringList(context, TABLE, showColumn);
	}

	public long add(Context context, ContentValues values) {
		return super.add(context, TABLE, values);
	}

	public int update(Context context, ContentValues setValues,
			String whereClause) {
		return super.update(context, TABLE, setValues, whereClause);
	}
	
	public int delete(Context context,String whereClause){
		return super.delete(context, TABLE, whereClause);
	}
}
