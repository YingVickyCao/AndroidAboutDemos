package com.ssyw.exam.controller;

import com.ssyw.exam.utility.DBManager;
import com.ssyw.exam.utility.NetWorkHelper;
import com.ssyw.exam.utility.WeiboHelper;

import android.content.Context;

public class WelcomeController {
	public void init(Context context) {
		new DBManager(context).openDatabase();// 导入数据库
		// 可以认为没有获取到外网IP就是没有连上网,并且只检查一次暂不考虑太多
		NetWorkHelper.getNetIpFromWeb(context);
		//暂时有些问题
		//NetWorkHelper.getLocation(context);
		WeiboHelper.setUpdateOauthV2Flag();
	}
}
