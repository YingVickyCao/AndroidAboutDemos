package com.ssyw.exam.model;

public class QuestionTypeService extends QuestionTypeDao {

}
