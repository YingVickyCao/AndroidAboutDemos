package com.ssyw.exam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.ssyw.exam.model.ExamResultEntry;
import com.ssyw.exam.model.ExamResultService;
import com.ssyw.exam.utility.WindowHelper;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class RecordActivity extends Activity {
	ListView lv_record;
	private WindowHelper wh;
	ArrayList<ExamResultEntry> entrylist;
	ExamResultService examResultService;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);// ȥ��������
		setContentView(R.layout.activity_record);
		wh = new WindowHelper(this);
		lv_record = (ListView) findViewById(R.id.lv_record);
		entrylist = new ArrayList<ExamResultEntry>();
		ExamResultService examResultService = new ExamResultService();
		final ArrayList<Map<String, Object>> getEntryList = examResultService
				.getRecordEntryList(this);
		ArrayList<Map<String, Object>> itemList = new ArrayList<Map<String, Object>>();
		for (Map<String, Object> entry : getEntryList) {
			Map<String, Object> itemMap = new HashMap<String, Object>();
			itemMap.put("image", R.drawable.record);
			itemMap.put(
					"content",
					getString(R.string.record_times) + entry.get("_id")
							+ getString(R.string.record_exam) + "("
							+ entry.get("totalScore")
							+ getString(R.string.record_score) + ")");
			itemMap.put("dateTime", entry.get("dateTime"));
			itemList.add(itemMap);
			entrylist.add(new ExamResultEntry((Integer) entry.get("_id"),
					(Integer) entry.get("totalScore"), (Integer) entry
							.get("rightCount"), (Integer) entry
							.get("wrongCount"), (Integer) entry
							.get("totalCount"), (String) entry.get("dateTime"),
					(String) entry.get("useTime")));
		}
		SimpleAdapter simpleAdapter = new SimpleAdapter(this, itemList,
				R.layout.list_record, new String[] { "image", "content",
						"dateTime" }, new int[] { R.id.image,
						R.id.record_times, R.id.record_datatimes });
		simpleAdapter.notifyDataSetChanged();
		lv_record.setAdapter(simpleAdapter);
		lv_record.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Intent intent = new Intent(RecordActivity.this,
						DetailsRecordActivity.class);
				intent.putExtra("MODE", 2);
				intent.putExtra("examResult", entrylist.get(position));
				startActivity(intent);
				finish();
			}
		});
	}

	public void clearRecord(View view) {
		examResultService = new ExamResultService();
		for (ExamResultEntry entry : entrylist) {
			System.out.println(entry.get_id() + "");
			examResultService.delete(RecordActivity.this, entry.get_id());
		}
		finish();
	}

	public void shotView(View view) {
		wh.shotAndSave(wh.pic_path);
		Intent intent = new Intent(RecordActivity.this,
				ShareFriendActivity.class);
		startActivity(intent);
	}

	public void back(View view) {
		finish();
	}
}
