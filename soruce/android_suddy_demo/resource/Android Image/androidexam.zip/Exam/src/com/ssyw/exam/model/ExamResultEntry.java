package com.ssyw.exam.model;

import java.io.Serializable;

import android.content.ContentValues;

/**
 * @author Administrator
 * 
 */
@SuppressWarnings("serial")
public class ExamResultEntry implements Serializable {

	private int _id;
	private int totalScore;
	private int rightCount;
	private int wrongCount;
	private int totalCount;
	private String dateTime;
	private String useTime;

	public ContentValues getContentValueByEntry() {
		ContentValues values = new ContentValues();
		// values.put("_id", _id);
		values.put("totalScore", totalScore);
		values.put("rightCount", rightCount);
		values.put("wrongCount", wrongCount);
		values.put("totalCount", totalCount);
		values.put("dateTime", dateTime);
		values.put("useTime", useTime);
		return values;
	}

	public ExamResultEntry(int totalScore, int rightCount, int wrongCount,
			int totalCount, String dateTime, String useTime) {
		super();
		// TODO Auto-generated constructor stub
		this.totalScore = totalScore;
		this.rightCount = rightCount;
		this.wrongCount = wrongCount;
		this.totalCount = totalCount;
		this.dateTime = dateTime;
		this.useTime = useTime;
	}

	public ExamResultEntry(int _id, int totalScore, int rightCount,
			int wrongCount, int totalCount, String dateTime, String useTime) {
		super();
		// TODO Auto-generated constructor stub
		this._id = _id;
		this.totalScore = totalScore;
		this.rightCount = rightCount;
		this.wrongCount = wrongCount;
		this.totalCount = totalCount;
		this.dateTime = dateTime;
		this.useTime = useTime;
	}

	public ExamResultEntry() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int get_id() {
		return _id;
	}

	public void set_id(int _id) {
		this._id = _id;
	}

	public int getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}

	public int getRightCount() {
		return rightCount;
	}

	public void setRightCount(int rightCount) {
		this.rightCount = rightCount;
	}

	public int getWrongCount() {
		return wrongCount;
	}

	public void setWrongCount(int wrongCount) {
		this.wrongCount = wrongCount;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getUseTime() {
		return useTime;
	}

	public void setUseTime(String useTime) {
		this.useTime = useTime;
	}

	// private int _id;
	// private int totalScore;
	// private int choiceScore;
	// private int essayScore;
	// private int programmingScore;
	// private int tfngScore;
	// private String selfEvaluation="";
	// private String dateTime="";
	// private int rate;
	// public int get_id() {
	// return _id;
	// }
	// public void set_id(int _id) {
	// this._id = _id;
	// }
	// public int getTotalScore() {
	// return totalScore;
	// }
	// public void setTotalScore(int totalScore) {
	// this.totalScore = totalScore;
	// }
	// public int getChoiceScore() {
	// return choiceScore;
	// }
	// public void setChoiceScore(int choiceScore) {
	// this.choiceScore = choiceScore;
	// }
	// public int getEssayScore() {
	// return essayScore;
	// }
	// public void setEssayScore(int essayScore) {
	// this.essayScore = essayScore;
	// }
	// public int getProgrammingScore() {
	// return programmingScore;
	// }
	// public void setProgrammingScore(int programmingScore) {
	// this.programmingScore = programmingScore;
	// }
	// public String getSelfEvaluation() {
	// return selfEvaluation;
	// }
	// public void setSelfEvaluation(String selfEvaluation) {
	// this.selfEvaluation = selfEvaluation;
	// }
	// public int getRate() {
	// return rate;
	// }
	// public void setRate(int rate) {
	// this.rate = rate;
	// }
	//
	// public int getTfngScore() {
	// return tfngScore;
	// }
	// public void setTfngScore(int tfngScore) {
	// this.tfngScore = tfngScore;
	// }
	//
	// public String getDateTime() {
	// return dateTime;
	// }
	// public void setDateTime(String dateTime) {
	// this.dateTime = dateTime;
	// }
	//
	// public ExamResultEntry(int totalScore, int choiceScore, int essayScore,
	// int programmingScore, int tfngScore, String selfEvaluation,
	// String dateTime, int rate) {
	// super();
	// this.totalScore = totalScore;
	// this.choiceScore = choiceScore;
	// this.essayScore = essayScore;
	// this.programmingScore = programmingScore;
	// this.tfngScore = tfngScore;
	// this.selfEvaluation = selfEvaluation;
	// this.dateTime = dateTime;
	// this.rate = rate;
	// }
	// public ContentValues getContentValueByEntry(){
	// ContentValues values=new ContentValues();
	// //values.put("_id", _id);
	// values.put("totalScore", totalScore);
	// values.put("choiceScore", choiceScore);
	// values.put("essayScore", essayScore);
	// values.put("tfngScore", tfngScore);
	// values.put("programmingScore", programmingScore);
	// values.put("selfEvaluation", selfEvaluation);
	// values.put("rate", rate);
	// values.put("dateTime", dateTime);
	// return values;
	// }

}
