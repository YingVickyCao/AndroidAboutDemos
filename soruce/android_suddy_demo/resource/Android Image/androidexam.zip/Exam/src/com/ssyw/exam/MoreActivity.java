package com.ssyw.exam;

import com.ssyw.exam.controller.MoreController;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.ListView;

public class MoreActivity extends Activity {

	private ListView lv_more_group;
	private MoreController mc = new MoreController();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_more);

		lv_more_group = (ListView) findViewById(R.id.lv_more_group);
		lv_more_group.setAdapter(mc.getGroupAdapter(this));
	}

}
