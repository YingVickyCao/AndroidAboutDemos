package com.ssyw.exam;

import com.ssyw.exam.controller.WelcomeController;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.annotation.SuppressLint;

import android.app.Activity;
import android.content.Intent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;


public class WelcomeActivity extends Activity {
	private WelcomeController wc=new WelcomeController();
	private Handler mHandler = new Handler();
	private ImageView iv_welcome;
	
	private int alpha = 255;
	private int b = 0;
	@SuppressLint("HandlerLeak")
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//FullScreen
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_welcome);
		
		wc.init(this);
		iv_welcome=(ImageView) findViewById(R.id.iv_welcome);
		iv_welcome.setAlpha(alpha);
		new Thread(new Runnable() {
			public void run() {
				while (b < 2) {
					try {
						if (b == 0) {
							Thread.sleep(500);
							b = 1;
						} else {
							Thread.sleep(100);
						}

						updateApp();

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}).start();

		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				iv_welcome.setAlpha(alpha);
				iv_welcome.invalidate();
			}
		};

	}

	public void updateApp() {
		alpha -= 5;
		//避免出现白屏
		if (alpha <= 30) {
			b = 2;
			Intent intent = new Intent(WelcomeActivity.this,MainTabActivity.class);
			startActivity(intent);
			this.finish();
		}

		mHandler.sendMessage(mHandler.obtainMessage());
	}

	
}
