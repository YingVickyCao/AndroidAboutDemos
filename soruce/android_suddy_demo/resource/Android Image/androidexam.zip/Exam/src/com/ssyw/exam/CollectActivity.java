package com.ssyw.exam;

import android.app.Activity;
import android.os.Bundle;

public class CollectActivity extends Activity {
//	private ListView listView_collect;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_collect);
//		listView_collect=(ListView) findViewById(R.id.listView_collect);
		
	}
}
