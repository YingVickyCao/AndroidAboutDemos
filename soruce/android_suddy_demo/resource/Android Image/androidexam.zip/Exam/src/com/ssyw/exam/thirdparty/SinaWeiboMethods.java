package com.ssyw.exam.thirdparty;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.ssyw.exam.R;
import com.ssyw.exam.utility.Utility;
import com.weibo.sdk.android.Oauth2AccessToken;
import com.weibo.sdk.android.WeiboException;
import com.weibo.sdk.android.api.StatusesAPI;
import com.weibo.sdk.android.keep.AccessTokenKeeper;
import com.weibo.sdk.android.net.RequestListener;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

@SuppressLint("HandlerLeak")
public class SinaWeiboMethods implements WeiboMethods {
	private static boolean updateOauthV2Flag = false;
	private static Oauth2AccessToken oauth2AccessToken;
	private StatusesAPI statusesAPI;
	private Context context;

	public void setUpdateOauthV2Flag(boolean updateOauthV2Flag) {
		SinaWeiboMethods.updateOauthV2Flag = updateOauthV2Flag;
	}

	public SinaWeiboMethods(Context context) {
		this.context = context;
	}

	@Override
	public void saveOauthV2(Context context, Object oAuth) {
		// TODO Auto-generated method stub
		Oauth2AccessToken accessToken = (Oauth2AccessToken) oAuth;
		AccessTokenKeeper.keepAccessToken(context, accessToken);
		updateOauthV2Flag = true;
	}

	private Oauth2AccessToken getOauth2AccessToken(Context context) {
		if (updateOauthV2Flag) {
			oauth2AccessToken = AccessTokenKeeper.readAccessToken(context);
			if (oauth2AccessToken.getToken().equals("")) {
				Log.e("getOauth2AccessToken", "empty");
			}
			updateOauthV2Flag = false;
		}
		return oauth2AccessToken;
	}

	@Override
	public void sendOneWeibo(final Context context, final String content) {
		this.sendOneWeibo(context, content, "", "", "");
	}

	@Override
	public void sendOneWeibo(final Context context, final String content,
			final String latitude, final String longitude, String clientip) {
		statusesAPI = new StatusesAPI(getOauth2AccessToken(context));
		new Thread() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				statusesAPI.update(content, latitude, longitude,
						getSendRequestListener());
			}
		}.start();
	}

	@Override
	public void sendOneWeibo(Context context, final String content,
			final String file, final String latitude, final String longitude,
			String clientip) {
		// TODO Auto-generated method stub
		statusesAPI = new StatusesAPI(getOauth2AccessToken(context));
		new Thread() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				statusesAPI.upload(content, file, latitude, longitude,
						getSendRequestListener());
			}
		}.start();
	}

	@Override
	public void sendOneWeibo(Context context, String content, String pic) {
		// TODO Auto-generated method stub
		this.sendOneWeibo(context, content, pic, "", "", "");
	}

	private boolean parseSendResult(String response) {
		boolean sendResult = false;
		if (response != null) {
			try {
				JSONTokener jsonParser = new JSONTokener(response);
				JSONObject result = (JSONObject) jsonParser.nextValue();
				if (!result.has("errcode")) {
					sendResult = true;
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return sendResult;
	}

	@SuppressLint("HandlerLeak")
	final Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			Bundle data = msg.getData();
			Boolean response = data.getBoolean("response");
			if (response) {
				Utility.showToastLong(context, R.string.send_success);
			}else{
				Utility.showToastLong(context, R.string.send_fail);
			}
		}
	};
	
	private RequestListener getSendRequestListener() {
		
		
		return new RequestListener() {

			@Override
			public void onIOException(IOException e) {
				Message msg = new Message();
				Bundle data = new Bundle();
				data.putBoolean("response", false);
				msg.setData(data);
				handler.sendMessage(msg);
			}

			@Override
			public void onError(WeiboException e) {
				// TODO Auto-generated method stub
				Message msg = new Message();
				Bundle data = new Bundle();
				data.putBoolean("response", false);
				msg.setData(data);
				handler.sendMessage(msg);
			}

			@Override
			public void onComplete(String response) {
				Message msg = new Message();
				Bundle data = new Bundle();
			
				if (parseSendResult(response)) {
					data.putBoolean("response", true);
				} else {
					data.putBoolean("response", false);
				}
				msg.setData(data);
				handler.sendMessage(msg);
			}
		};
	}

	@Override
	public void clearOauthV2(Context context) {
		// TODO Auto-generated method stub

	}

}
