package com.ssyw.exam.model;

public class QuestionClassService extends QuestionClassDao {

}
