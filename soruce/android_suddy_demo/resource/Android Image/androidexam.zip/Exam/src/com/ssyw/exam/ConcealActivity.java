package com.ssyw.exam;

import com.ssyw.exam.utility.WindowHelper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

public class ConcealActivity extends Activity {
	private WindowHelper wh;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);// 去掉标题栏
		setContentView(R.layout.activity_conceal);
		wh=new WindowHelper(this);
	}
	public void shotView(View view) {
		wh.shotAndSave(wh.pic_path);
		Intent intent = new Intent(ConcealActivity.this,
				ShareFriendActivity.class);
		startActivity(intent);
	}

	public void back(View view) {
		finish();
	}
}
