package com.ssyw.exam.utility;

import java.io.File;
import java.io.FileOutputStream;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.View;

@SuppressLint({ "NewApi", "SdCardPath" })
@SuppressWarnings("deprecation")
public class WindowHelper {

	public final String pic_path;
	private Activity mActivity;
	private View views;
	public WindowHelper(Activity mActivity) {
		super();
		this.mActivity = mActivity;
		this.views=mActivity.getWindow().getDecorView();
		this.pic_path="/data/data/"
				+ PackageHelper.getAppInfo(mActivity).getAsString("packageName")
				+ "/image.png";
	}
	
	public Point getDefaultDisplaySize(){
		Display display = mActivity.getWindowManager().getDefaultDisplay();
		Point size = new Point();
		size.y=display.getHeight();
		size.x=display.getWidth();
		return size;
	}
	
	/**
	 * 
	 * @param file_path ͼƬ��ŵ�·��
	 * @param x        The x coordinate of the first pixel in source
     * @param y        The y coordinate of the first pixel in source
     * @param width    The number of pixels in each row
     * @param height   The number of rows
	 * @return
	 */
	public Bitmap shotAndSave(String file_path,int x, int y, int width, int height) {
		views.buildDrawingCache();		
		Bitmap bmp = Bitmap.createBitmap(views.getDrawingCache(), x,
				y, width, height);	
		File file = new File(file_path);
		try {
			FileOutputStream out = new FileOutputStream(file);
			if (bmp.compress(Bitmap.CompressFormat.PNG, 70, out)) {
				out.flush();
				out.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bmp;
	}
	
	public Bitmap shotAndSave(String file_path) {
		Rect frames = new Rect();
		views.getWindowVisibleDisplayFrame(frames);
		int statusBarHeight = frames.top;
		Point size = getDefaultDisplaySize();
		return this.shotAndSave(file_path, 0, statusBarHeight, size.x, size.y-statusBarHeight);
		
	}
}
