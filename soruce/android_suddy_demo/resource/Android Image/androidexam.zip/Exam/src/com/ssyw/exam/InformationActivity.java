package com.ssyw.exam;
import com.ssyw.exam.utility.WindowHelper;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.ImageButton;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ImageView.ScaleType;
import android.widget.Toast;
import android.widget.ViewSwitcher.ViewFactory;


@SuppressWarnings("deprecation")
public class InformationActivity extends Activity implements ViewFactory{
	
	private SharedPreferences prference;   
	private String PREF_NAME = "PREF_NAME";  
	private String PREF_SEX ="PREF_SEX";
	private String KEY = "TestValue"; 
	private String KEY2 = "sexValue"; 

	Button btn_information_save;
	private WindowHelper wh;
	EditText et_name,et_score,et_sex;
	ImageButton information_imagebutton;//头像按钮
	View imageChooseView;//图像选择的视图
	AlertDialog imageChooseDialog;//头像选择对话框
	Gallery gallery;//头像的Gallery
	ImageSwitcher is;//头像的ImageSwitcher
	int currentImagePosition;//用于记录当前选中图像在图像数组中的位置
	int previousImagePosition;//用于记录上一次图片的位置
	boolean imageChanged;//判断头像有没有变化
	/**
	 * 所有的图像图片
	 */
	private  int[] images 
			= new int[]{
		R.drawable.image_1,R.drawable.image_2,R.drawable.image_3
		,R.drawable.image_4,R.drawable.image_5,R.drawable.image_6
		,R.drawable.image_7,R.drawable.image_8,R.drawable.image_9
		,R.drawable.image_10};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);// 去掉标题栏
		setContentView(R.layout.activity_information);
		wh=new WindowHelper(this);
		information_imagebutton=(ImageButton) findViewById(R.id.information_imagebutton);
		et_name=(EditText) findViewById(R.id.et_name);
		et_score=(EditText) findViewById(R.id.et_score);
		et_sex=(EditText) findViewById(R.id.et_sex);
		btn_information_save=(Button) findViewById(R.id.btn_information_save);
		et_name.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
			nameTitleDialog();
			}
		});
		et_sex.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
			new AlertDialog.Builder(InformationActivity.this)
			.setTitle("sex")
			.setMessage(getString(R.string.sex))
			.setPositiveButton(getString(R.string.set_sex_man),new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					et_sex.setText(getString(R.string.set_sex_man));
				}
			})
			.setNegativeButton(getString(R.string.set_sex_woman), new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					et_sex.setText(getString(R.string.set_sex_woman));
					
				}
			})
			.show();
		}
	});
		
		information_imagebutton.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				
				loadImage();//为gallery装载图片
				initImageChooseDialog();//初始化imageChooseDialog
				imageChooseDialog.show();
			}
		});
//	btn_information_save
  btn_information_save.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {

		prference = getSharedPreferences(PREF_NAME, MODE_PRIVATE );   
		prference = getSharedPreferences(PREF_SEX, MODE_PRIVATE );   
		prference.edit().putString(KEY, et_name.getText().toString()).commit();  
		prference.edit().putString(KEY2, et_sex.getText().toString()).commit(); 
		}
	});
	}
	
	protected void nameTitleDialog() {
		final EditText inputServer = new EditText(this);
		inputServer.setFocusable(true);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(getString(R.string.set_name))
		       .setIcon(R.drawable.ic_launcher)
			   .setView(inputServer);
		
		builder.setPositiveButton(getString(R.string.setsure), new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				if (null == inputServer|| "".equals(inputServer.getText().toString())) {
					Toast.makeText(InformationActivity.this, getString(R.string.name_notnull),
							Toast.LENGTH_SHORT).show();
				}
				et_name.setText(inputServer.getText().toString());
			}
		});
		builder.setNegativeButton(getString(R.string.set_cancel), new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
			}
		});
		builder.show();
		
	}

	public void loadImage() {
		if(imageChooseView == null) {
			//手动产生一个Layout
			LayoutInflater li = LayoutInflater.from(InformationActivity.this);
			imageChooseView = li.inflate(R.layout.images_witch, null);
			
			is = (ImageSwitcher)imageChooseView.findViewById(R.id.imageswitch);
			is.setFactory(this);
			is.setInAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));
	        //卸载图片的动画效果
	        is.setOutAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_out));
	        //通过渲染xml文件，得到一个视图（View）即Gallery，再拿到这个View里面的Gallery
			gallery = (Gallery)imageChooseView.findViewById(R.id.gallery);
			//为Gallery装载图片
			gallery.setAdapter(new ImageAdapter(this));
			//选择中间那张图片显示在ImageSwitch组件中
			gallery.setSelection(images.length/2);
	        gallery.setOnItemSelectedListener(new OnItemSelectedListener(){

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					//当前的头像位置为选中的位置
					currentImagePosition = arg2;
					//为ImageSwitcher设置图像
					is.setImageResource(images[arg2 % images.length]);
				}
				@Override
				public void onNothingSelected(AdapterView<?> arg0) {
				}});
		}
	}
	
	/**
	 * 自定义Gallery的适配器
	 * @author Administrator
	 *
	 */
	class ImageAdapter extends BaseAdapter {

		private Context context;
		
		public ImageAdapter(Context context) {
			this.context = context;
		}
		
		//可选个数是Integer最大值
		@Override
		public int getCount() {
			return Integer.MAX_VALUE;
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		
		/**
		 * gallery从这个方法中拿到image
		 */
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView iv = new ImageView(context);
			iv.setImageResource(images[position%images.length]);
			iv.setAdjustViewBounds(true);
			iv.setLayoutParams(new Gallery.LayoutParams(80,80));
			iv.setPadding(15, 10, 15, 10);
			return iv;
		}
	}

	
	@Override
		public View makeView() {
		ImageView view = new ImageView(this);
		view.setBackgroundColor(0xff000000);
		view.setScaleType(ScaleType.FIT_CENTER);
		view.setLayoutParams(new ImageSwitcher.LayoutParams(90,90));
		return view;
	}
		public void initImageChooseDialog() {
		if(imageChooseDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle(getString(R.string.Information_title))
			.setView(imageChooseView).setPositiveButton(getString(R.string.Information_surebutton), new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					imageChanged = true;
					previousImagePosition = currentImagePosition;
					information_imagebutton.setImageResource(images[currentImagePosition%images.length]);
				}
			})
			.setNegativeButton(getString(R.string.Information_cancel), new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					currentImagePosition = previousImagePosition;
					
				}
			});
			imageChooseDialog = builder.create();
		}
	}
	
	/**
	 * 当退出的时候，回收资源
	 */
	@Override
	protected void onDestroy() {
		if(is != null) {
			is = null;
		}
		if(gallery != null) {
			gallery = null;
		}
		if(imageChooseDialog != null) {
			imageChooseDialog = null;
		}
		if(imageChooseView != null) {
			imageChooseView = null;
		}
		if(information_imagebutton != null) {
			information_imagebutton = null;
		}
		
		super.onDestroy();
	}
	public void shotView(View view) {
		wh.shotAndSave(wh.pic_path);
		Intent intent = new Intent(InformationActivity.this,
				ShareFriendActivity.class);
		startActivity(intent);
	}
	public void back(View view) {
		finish();
	}
}
