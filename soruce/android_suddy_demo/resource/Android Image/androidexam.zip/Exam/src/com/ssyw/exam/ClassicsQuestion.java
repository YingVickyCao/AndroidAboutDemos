package com.ssyw.exam;

import java.util.ArrayList;
import java.util.Map;

import com.ssyw.exam.model.QuestionBankService;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class ClassicsQuestion extends Activity {
	ListView listView_classics_question;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_classics_question);
		listView_classics_question=(ListView) findViewById(R.id.listView_classics_question);
		QuestionBankService questionBank = new QuestionBankService();
		final ArrayList<Map<String, Object>> getEntryList = questionBank
			.getClassicsEntryList(this);
		final SimpleAdapter simpleAdapter = new SimpleAdapter(this,
				getEntryList, R.layout.list_classics_question, new String[] {
						"_id" ,"question" }, new int[] { R.id.list_classics_id,
						R.id.list_classics_name });
		listView_classics_question.setAdapter(simpleAdapter);
		simpleAdapter.notifyDataSetChanged();
		listView_classics_question.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				
				Intent intent=new Intent(ClassicsQuestion.this,ClassicsQuestionOne.class);
				intent.putExtra("questionId", (Integer) getEntryList.get(position).get("_id"));
				startActivity(intent);
			}
		});
	}
}
