package com.ssyw.exam.utility;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences;
import android.widget.Toast;

public class Utility {

	public static void showAlertOnly(Context context, int messageId,
			int textId, int titleId) {
		new AlertDialog.Builder(context).setMessage(messageId)
				.setTitle(titleId).setPositiveButton(textId, null).show();
	}

	public static void showQueryAlert(Context context, int messageId,
			int textPositiveId, int textNegativeId, int titleId,
			OnClickListener onPositiveClickListener,
			OnClickListener onNegativeClickListener) {
		new AlertDialog.Builder(context).setMessage(messageId)
				.setTitle(titleId)
				.setPositiveButton(textPositiveId, onPositiveClickListener)
				.setNegativeButton(textNegativeId, onNegativeClickListener)
				.show();
	}

	public static void writeSharedPreferences(Context context, String name,
			String key, String value) {
		SharedPreferences setting = context.getSharedPreferences(name,
				Context.MODE_APPEND);
		SharedPreferences.Editor ed = setting.edit();
		ed.putString(key, value);
		ed.commit();
	}

	public static String readSharedPreferences(Context context, String name,
			String key, String defvalue) {
		SharedPreferences setting = context.getSharedPreferences(name,
				Context.MODE_APPEND);
		return setting.getString(key, defvalue);
	}

	public static void showToastLong(Context context, String str) {
		Toast.makeText(context, str, Toast.LENGTH_LONG).show();
	}

	public static void showToastShort(Context context, String str) {
		Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
	}

	public static void showToastLong(Context context, int resId) {
		Toast.makeText(context, resId, Toast.LENGTH_LONG).show();
	}

	public static void showToastShort(Context context, int resId) {
		// TODO Auto-generated method stub
		Toast.makeText(context, resId, Toast.LENGTH_SHORT).show();
	}
}
