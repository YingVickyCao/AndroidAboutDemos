package com.ssyw.exam.model;

import java.util.ArrayList;
import java.util.Map;

import android.content.Context;
import android.database.Cursor;

/**
 * @author sxenon All table needed
 */
public class CommonDao extends BaseDao {
	protected ArrayList<Map<String, Object>> getEntryList(Context context,
			String table) {
		Cursor cursor = getCursorByQuery(context, false, table, null, null,
				null, null, null, null);
		return getMapListByCursor(cursor);
	}

	protected ArrayList<Map<String, Object>> getEntryList(Context context,
			String table,String whereValues,String limit) {
		Cursor cursor = getCursorByQuery(context, false, table, null, null,
				null, null, null, limit);
		return getMapListByCursor(cursor);
	}
	
	protected ArrayList<Map<String, Object>> getEntryList(Context context,
			String table,String whereValues) {
		Cursor cursor = getCursorByQuery(context, false, table, null, whereValues,
				null, null, null, null);
		return getMapListByCursor(cursor);
	}
	// 通用
	protected Map<String, Object> getEntry(Context context, String table,
			String whereClause, boolean distinct, String groupBy,
			String having, String orderBy, String limit) {
		Cursor cursor = getCursorByQuery(context, distinct, table, null,
				whereClause, groupBy, having, orderBy, limit);
		return getMapByCursor(cursor);
	}

	protected ArrayList<String> getStringList(Context context, String table,
			String showColumn, boolean distinct, String whereValues,
			String groupBy, String having, String limit, String orderBy) {
		String[] showColumns = new String[] { showColumn };
		Cursor cursor = getCursorByQuery(context, distinct, table, showColumns,
				whereValues, groupBy, having, orderBy, limit);
		return getStringListByCursor(cursor);
	}

	protected ArrayList<Integer> getIntegerList(Context context, String table,
			String showColumn, boolean distinct, String whereValues,
			String groupBy, String having, String limit, String orderBy) {
		String[] showColumns = new String[] { showColumn };
		Cursor cursor = getCursorByQuery(context, distinct, table, showColumns,
				whereValues, groupBy, having, orderBy, limit);
		return getIntegerListByCursor(cursor);
	}

	protected ArrayList<Float> getFloatList(Context context, String table,
			String showColumn, boolean distinct, String whereValues,
			String groupBy, String having, String limit, String orderBy) {
		String[] showColumns = new String[] { showColumn };
		Cursor cursor = getCursorByQuery(context, distinct, table, showColumns,
				whereValues, groupBy, having, orderBy, limit);
		return getFloatListByCursor(cursor);
	}

	//简化
	protected ArrayList<Integer> getIntegerList(Context context, String table,
			String showColumn) {
		return this.getIntegerList(context, table, showColumn, false, null,
				null, null, null, null);
	}

	protected ArrayList<Float> getFloatList(Context context, String table,
			String showColumn) {
		return this.getFloatList(context, table, showColumn, false, null, null,
				null, null, null);
	}

	protected ArrayList<String> getStringList(Context context, String table,
			String showColumn) {
		return this.getStringList(context, table, showColumn, false, null,
				null, null, null, null);
	}

	protected Map<String, Object> getEntry(Context context, String table,
			String whereValues) {
		return this.getEntry(context, table, whereValues, false, null, null,
				null, null);
	}

	protected ArrayList<Integer> getIntegerList(Context context, String table,
			String showColumn, String whereValues) {
		return this.getIntegerList(context, table, showColumn, false,
				whereValues, null, null, null, null);
	}
}
