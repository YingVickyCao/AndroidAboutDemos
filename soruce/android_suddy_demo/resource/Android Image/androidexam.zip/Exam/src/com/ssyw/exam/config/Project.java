package com.ssyw.exam.config;

/**
 * @author accer
 * project config
 */
public class Project {
	private static final String NAME="android";
	private static final String TYPE="exam";
	public static final String PROJECT=TYPE+"_"+NAME;
	public static final boolean DEBUG_FLAG=true;
}
