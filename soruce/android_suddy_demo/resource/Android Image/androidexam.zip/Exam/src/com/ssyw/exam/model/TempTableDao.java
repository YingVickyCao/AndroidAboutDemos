package com.ssyw.exam.model;

import android.content.ContentValues;
import android.content.Context;

public class TempTableDao extends CommonDao {
	protected boolean checkTableExist(Context context, String table) {
		return super.checkTableExist(context, table);
	}

	protected void createTable(Context context, String table, String value) {
		super.createTable(context, table, value);
	}

	protected void dropTable(Context context, String table) {
		super.dropTable(context, table);
	}

	public long add(Context context, String table, ContentValues values) {
		return super.add(context, table, values);
	}
}
