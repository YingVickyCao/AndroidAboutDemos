package com.ssyw.exam.controller;

import java.util.ArrayList;
import java.util.List;

import com.ssyw.exam.R;
import com.ssyw.exam.widget.RoundedListViewAdapter;

import android.content.Context;

public class MoreController {

	public RoundedListViewAdapter getGroupAdapter(Context context) {
		List<String> titleDatas = new ArrayList<String>();
		List<String> promptDatas = new ArrayList<String>();
		titleDatas.add(getStringById(context, R.string.person_information));
		titleDatas.add(getStringById(context, R.string.privacy_treaty));
		titleDatas.add(getStringById(context, R.string.share_setting));
		titleDatas.add(getStringById(context, R.string.help));
		titleDatas.add(getStringById(context, R.string.about));

		promptDatas.add("");
		promptDatas.add("");
		promptDatas.add("");
		promptDatas.add("");
		promptDatas.add("");
	
		return new RoundedListViewAdapter(titleDatas, promptDatas, context,
				RoundedListViewAdapter.MORE_GROUP);
	}

	private String getStringById(Context context, int resId) {
		return context.getResources().getString(resId);
	}
}
