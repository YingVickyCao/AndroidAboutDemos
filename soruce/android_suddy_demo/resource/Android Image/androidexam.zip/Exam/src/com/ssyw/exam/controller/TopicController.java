package com.ssyw.exam.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.ssyw.exam.model.ExamResultEntry;
import com.ssyw.exam.model.ExamResultService;
import com.ssyw.exam.model.QuestionBankService;
import com.ssyw.exam.model.TempTableService;

@SuppressLint("UseSparseArrays")
public class TopicController {
	private QuestionBankService questionBankService;
	private ExamResultService examResultService;
	private TempTableService tempTableService;
	private HashMap<Integer, String> itemMap;
	private HashMap<Integer, Integer> examMap;

	public TopicController() {
		questionBankService = new QuestionBankService();
		examResultService = new ExamResultService();
		tempTableService = new TempTableService();
		itemMap = new HashMap<Integer, String>();
		itemMap.put(1, "opt1");
		itemMap.put(2, "opt2");
		itemMap.put(3, "opt3");
		itemMap.put(4, "opt4");
	}

	public ArrayList<Map<String, Object>> sequentialSearch(Context context) {
		return questionBankService.sequentialSearch(context);
	}

	public ArrayList<Map<String, Object>> randomSearch(Context context) {
		return questionBankService.randomSearch(context);
	}

	public ArrayList<Map<String, Object>> textSearch(Context context) {
		return questionBankService.textSearch(context);
	}

	public ArrayList<Map<String, Object>> errorBookSearch(Context context) {
		return questionBankService.errorBookSearch(context);
	}

	public ArrayList<Map<String, Object>> collectedSearch(Context context) {
		return questionBankService.collectedSearch(context);
	}

	public boolean checkTableExist(Context context, String table) {
		return tempTableService.checkTableExist(context, table);
	}

	public void dropTable(Context context, String table) {
		tempTableService.dropTable(context, table);
	}

	public void createTable(Context context, String table,
			ArrayList<Map<String, Object>> mapList) {
		tempTableService.createTable(context, table);
		this.initTable(context, table, mapList);
	}

	protected void initTable(Context context, String table,
			ArrayList<Map<String, Object>> mapList) {
		ContentValues values = new ContentValues();
		int count = 1;
		for (Map<String, Object> map : mapList) {
			values.put("tempId", count);
			values.put("_id", Integer.valueOf((String) map.get("_id")));
			tempTableService.add(context, table, values);
			count++;
		}
	}

	public void initDaoIdMap(int type) {
		if (type != 1) {
			examMap = questionBankService.getExamMap();
		}
		System.out.println("EXAMMAPCOUNT:" + examMap.size());
	}

	public boolean isDataIdMapNull() {
		if (examMap.size() == 0) {
			return true;
		} else {
			return false;
		}
	}

	public int getDaoId(Context context, int type, int id) {
		int returnId = -1;
		switch (type) {
		case 1: {
			returnId = id;
			break;
		}
		case 2: {
			returnId = examMap.get(id);
			break;
		}
		case 5: {
			returnId = examMap.get(id);
			break;
		}
		case 6: {
			returnId = examMap.get(id);
			break;
		}
		case 7: {
			returnId = examMap.get(id);
			break;
		}
		default:
			break;
		}
		// System.out.println("" + returnId);
		return returnId;
	}

	public int getCollectedFlag(Context context, int id) {
		return questionBankService.getCollectedFlag(context, id);
	}

	public void setCollectedFlag(Context context, int id) {
		questionBankService.setCollectedFlag(context, id);
	}

	public void resetCollectedFlag(Context context, int id) {
		questionBankService.resetCollectedFlag(context, id);
	}

	public void addRightCount(Context context, int id) {
		questionBankService.addRightTime(context, id);
	}

	public void addWrongCount(Context context, int id) {
		questionBankService.addWrongTime(context, id);
		questionBankService.setInWrongFlag(context, id);
	}

	public String getAnswer(Context context, int id) {
		return questionBankService.getAnswer(context, id);
	}

	public RadioButton getCorrectRadioButton(Context context, RadioGroup rg,
			HashMap<String, Integer> orderMap, String answer) {
		RadioButton returnRb = new RadioButton(context);
		switch (rg.getChildCount()) {
		case 2: {
			RadioButton rb_item1 = (RadioButton) rg.getChildAt(0);
			RadioButton rb_item2 = (RadioButton) rg.getChildAt(1);
			if (String
					.valueOf(
							orderMap.get(rb_item1
									.getText()
									.toString()
									.substring(
											0,
											rb_item1.getText().toString()
													.indexOf(".")))).equals(
							answer)) {
				returnRb = rb_item1;
			} else {
				returnRb = rb_item2;
			}
			break;
		}
		case 4: {
			RadioButton rb_item1 = (RadioButton) rg.getChildAt(0);
			RadioButton rb_item2 = (RadioButton) rg.getChildAt(1);
			RadioButton rb_item3 = (RadioButton) rg.getChildAt(2);
			RadioButton rb_item4 = (RadioButton) rg.getChildAt(3);
			if (String
					.valueOf(
							orderMap.get(rb_item1
									.getText()
									.toString()
									.substring(
											0,
											rb_item1.getText().toString()
													.indexOf(".")))).equals(
							answer)) {
				returnRb = rb_item1;
			} else if (String
					.valueOf(
							orderMap.get(rb_item2
									.getText()
									.toString()
									.substring(
											0,
											rb_item2.getText().toString()
													.indexOf(".")))).equals(
							answer)) {
				returnRb = rb_item2;
			} else if (String
					.valueOf(
							orderMap.get(rb_item3
									.getText()
									.toString()
									.substring(
											0,
											rb_item3.getText().toString()
													.indexOf(".")))).equals(
							answer)) {
				returnRb = rb_item3;
			} else {
				returnRb = rb_item4;
			}
			break;
		}
		default:
			break;
		}
		return returnRb;
	}

	public void setRadioButtonState(RadioGroup rg, boolean bl) {
		switch (rg.getChildCount()) {
		case 2: {
			RadioButton rb_item1 = (RadioButton) rg.getChildAt(0);
			RadioButton rb_item2 = (RadioButton) rg.getChildAt(1);
			rb_item1.setEnabled(bl);
			rb_item2.setEnabled(bl);
			break;
		}
		case 4: {
			RadioButton rb_item1 = (RadioButton) rg.getChildAt(0);
			RadioButton rb_item2 = (RadioButton) rg.getChildAt(1);
			RadioButton rb_item3 = (RadioButton) rg.getChildAt(2);
			RadioButton rb_item4 = (RadioButton) rg.getChildAt(3);
			rb_item1.setEnabled(bl);
			rb_item2.setEnabled(bl);
			rb_item3.setEnabled(bl);
			rb_item4.setEnabled(bl);
			break;
		}
		default:
			break;
		}
	}

	public void addTestScore(Context context, int totalScore, int rightCount,
			int wrongCount, int totalCount, String dateTime, String useTime) {
		examResultService.addTestScore(context, totalScore, rightCount,
				wrongCount, totalCount, dateTime, useTime);
	}

	public ExamResultEntry getThisTestScore() {
		return examResultService.getThisTestScore();
	}

	public HashMap<String, Integer> getOrderMap(int topicType) {
		HashMap<String, Integer> orderMap = new HashMap<String, Integer>();
		ArrayList<Integer> tempList = new ArrayList<Integer>();
		if (topicType == 1) {
			tempList.add(1);
			tempList.add(2);
			tempList.add(3);
			tempList.add(4);
			Random random = new Random();
			int size = tempList.size();
			int sizeNumber;
			int tempInt;
			int count = 1;
			while (size > 0) {
				sizeNumber = random.nextInt(size);
				tempInt = count + 64;
				orderMap.put(String.valueOf((char) tempInt),
						tempList.get(sizeNumber));
				tempList.remove(sizeNumber);
				size = tempList.size();
				count++;
			}
		} else {
			orderMap.put("A", 1);
			orderMap.put("B", 2);
		}

		return orderMap;
	}

	public String getItemValue(Integer tempInt) {
		return itemMap.get(tempInt);
	}
}
