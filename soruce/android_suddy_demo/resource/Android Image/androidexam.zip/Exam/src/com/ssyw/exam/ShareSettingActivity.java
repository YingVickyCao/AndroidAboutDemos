package com.ssyw.exam;

import com.ssyw.exam.controller.ShareSettingController;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ListView;

public class ShareSettingActivity extends Activity {
	private ListView lv_share_group;
	private ShareSettingController ssc;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_share_setting);
		
		ssc=new ShareSettingController();
		lv_share_group=(ListView) findViewById(R.id.lv_share_group);
		lv_share_group.setAdapter(ssc.getGroupAdapter(this));
	}
	
	public void back(View v){
		finish();
	}
}
