package com.ssyw.exam.controller;


import android.app.Activity;
import android.content.Context;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class MainTabController {
	@SuppressWarnings("unused")
	private Activity mActivity;
	public MainTabController(Activity mActivity) {
		super();
		this.mActivity = mActivity;
	}

	public class ImageAdapter extends BaseAdapter {
		private ImageView[] imageItems;
		private int[] selectedResId;
		private int[] unselectedResId;
		
		public ImageAdapter(Context context, int[] picIds, int width, int height,
				int[] selectedResId,int[] unselectedResId) {
			this.selectedResId = selectedResId;
			this.unselectedResId=unselectedResId;
			imageItems = new ImageView[picIds.length];
			for (int i = 0; i < picIds.length; i++) {
				imageItems[i] = new ImageView(context);
				/* 设置ImageView宽高 */
				// imageItems[i].setLayoutParams(new GridView.LayoutParams(width,height));
				imageItems[i].setAdjustViewBounds(false);
				// imgItems[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
				imageItems[i].setPadding(2, 2, 2, 2);
				imageItems[i].setImageResource(picIds[i]);
			}
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return imageItems.length;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView imageView;
			if (convertView == null) {
				imageView = imageItems[position];
			} else {
				imageView = (ImageView) convertView;
			}
			return imageView;
		}

		/* 设置选中焦点 */
		public void setFocus(int index) {
			for (int i = 0; i < imageItems.length; i++) {
				if (i != index) {
					/* 恢复未选中的样式 */
					// imageItems[i].setBackgroundResource(0);
					imageItems[i].setImageResource(unselectedResId[i]);
				}
			}
			/* 设置选中的样式 */
			// imageItems[index].setBackgroundResource(selectedResId[index]);
			imageItems[index].setImageResource(selectedResId[index]);
		}

	}
}
