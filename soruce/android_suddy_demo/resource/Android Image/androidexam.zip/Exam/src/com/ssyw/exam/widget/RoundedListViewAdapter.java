package com.ssyw.exam.widget;

import java.util.ArrayList;
import java.util.List;

import com.ssyw.exam.AboutActivity;
import com.ssyw.exam.ConcealActivity;
import com.ssyw.exam.ShareSettingActivity;
import com.ssyw.exam.HelpActivity;
import com.ssyw.exam.InformationActivity;
import com.ssyw.exam.R;
import com.ssyw.exam.thirdparty.SinaWeiboMethods;
import com.ssyw.exam.thirdparty.TencentWeiboOAuthV2;
import com.weibo.sdk.android.Oauth2AccessToken;
import com.weibo.sdk.android.Weibo;
import com.weibo.sdk.android.WeiboAuthListener;
import com.weibo.sdk.android.WeiboDialogError;
import com.weibo.sdk.android.WeiboException;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @title RoundedListViewAdapter listview的适配器
 * @company 探索者网络工作室(www.tsz.net)
 * @author michael Young (www.YangFuhai.com)
 * @description sxenon修改版
 * @version 1.1
 * @created 2013-3-8
 */
public class RoundedListViewAdapter extends BaseAdapter {

	private List<String> titleDatas = new ArrayList<String>(); // 菜单数据
	private List<String> promptDatas = new ArrayList<String>();
	private Context mContext;
	// 这是打补丁的解决方式
	public int group_id;
	public static final int MORE_GROUP = 0;
	public static final int SHARE_GROUP = 1;

	//sinaWeibo  再打补丁
	private Weibo mWeibo;
	private static final String CONSUMER_KEY = "3124960049";// 替换为开发者的appkey，例如"1646212860";
	private static final String REDIRECT_URL = "http://apps.weibo.com/exam_android";
	public static Oauth2AccessToken accessToken;
	public static final String TAG = "sinasdk";

	public RoundedListViewAdapter(List<String> titleDatas,
			List<String> promptDatas, Context mContext, int group_id) {
		super();
		this.titleDatas = titleDatas;
		this.promptDatas = promptDatas;
		this.mContext = mContext;
		this.group_id = group_id;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return titleDatas.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return titleDatas.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		View view = null;
		String title = titleDatas.get(position);
		String prompt = promptDatas.get(position);
		if (titleDatas.size() > 1) {// listView 数据是两条以上
			if (position == 0) { // 第一条数据
				String titleNext = titleDatas.get(position + 1);
				if (TextUtils.isEmpty(titleNext)) {
					view = View.inflate(mContext, R.layout.list_rounded_single,
							null);
				} else {
					view = View.inflate(mContext, R.layout.list_rounded_top,
							null);
				}
			} else if (position == titleDatas.size() - 1) { // 最后一条数据
				String titlePre = titleDatas.get(position - 1);
				if (TextUtils.isEmpty(titlePre)) {
					view = View.inflate(mContext, R.layout.list_rounded_single,
							null);
				} else {
					view = View.inflate(mContext, R.layout.list_rounded_bottom,
							null);
				}
			} else { // 中间的数据
				String titleNext = titleDatas.get(position + 1);
				String titlePre = titleDatas.get(position - 1);
				if (TextUtils.isEmpty(title)) {
					view = View.inflate(mContext, R.layout.list_rounded_blank,
							null);
				} else if (TextUtils.isEmpty(titleNext)
						&& TextUtils.isEmpty(titlePre)) {
					view = View.inflate(mContext, R.layout.list_rounded_single,
							null);
				} else if (TextUtils.isEmpty(titleNext)) {
					view = View.inflate(mContext, R.layout.list_rounded_bottom,
							null);
				} else if (TextUtils.isEmpty(titlePre)) {
					view = View.inflate(mContext, R.layout.list_rounded_top,
							null);
				} else {
					view = View.inflate(mContext, R.layout.list_rounded_middle,
							null);
				}
			}
		} else { // 只有一条数据
			view = View.inflate(mContext, R.layout.list_rounded_single, null);
		}
		if (!TextUtils.isEmpty(title)) {
			((TextView) view.findViewById(R.id.tv_title)).setText(title);
			((TextView) view.findViewById(R.id.tv_prompt)).setHint(prompt);// 设置文本样式
		}
		switch (group_id) {
		case MORE_GROUP:
			view.setOnClickListener(new OnClickListener() {
				Intent intent = null;

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					switch (position) {
					case 0:
						intent = new Intent(mContext, InformationActivity.class);
						break;
					case 1:
						intent = new Intent(mContext, ConcealActivity.class);
						break;
					case 2:
						intent = new Intent(mContext,
								ShareSettingActivity.class);
						break;
					case 3:
						intent = new Intent(mContext, HelpActivity.class);
						break;
					case 4:
						intent = new Intent(mContext, AboutActivity.class);
						break;
					default:
						break;
					}
					if (intent != null) {
						mContext.startActivity(intent);
					}
				}

			});
			break;

		case SHARE_GROUP:
			view.setOnClickListener(new OnClickListener() {
				Intent intent = null;

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					switch (position) {
					case 0:
						mWeibo = Weibo.getInstance(CONSUMER_KEY, REDIRECT_URL);
						mWeibo.authorize(mContext, new AuthDialogListener());
						break;
					case 1:
						intent = new Intent(mContext, TencentWeiboOAuthV2.class);
						break;
					default:
						break;
					}
					if (intent != null) {
						mContext.startActivity(intent);
					}
				}
			});
			break;
		default:
			break;
		}
		return view;
	}

	class AuthDialogListener implements WeiboAuthListener {

		@SuppressWarnings("rawtypes")
		@Override
		public void onComplete(Bundle values) {
			String token = values.getString("access_token");
			String expires_in = values.getString("expires_in");
			accessToken = new Oauth2AccessToken(token, expires_in);
			if (accessToken.isSessionValid()) {
				try {
					@SuppressWarnings("unused")
					Class sso = Class
							.forName("com.weibo.sdk.android.api.WeiboAPI");// 如果支持weiboapi的话，显示api功能演示入口按钮
				} catch (ClassNotFoundException e) {
					// e.printStackTrace();
					Log.i(TAG, "com.weibo.sdk.android.api.WeiboAPI not found");

				}
				new SinaWeiboMethods(mContext).saveOauthV2(mContext, accessToken);
				Toast.makeText(mContext, "认证成功", Toast.LENGTH_SHORT).show();
			}
		}

		@Override
		public void onError(WeiboDialogError e) {
			Toast.makeText(mContext.getApplicationContext(),
					"Auth error : " + e.getMessage(), Toast.LENGTH_LONG).show();
		}

		@Override
		public void onCancel() {
			Toast.makeText(mContext.getApplicationContext(), "Auth cancel",
					Toast.LENGTH_LONG).show();
		}

		@Override
		public void onWeiboException(WeiboException e) {
			Toast.makeText(mContext.getApplicationContext(),
					"Auth exception : " + e.getMessage(), Toast.LENGTH_LONG)
					.show();
		}

	}
}
