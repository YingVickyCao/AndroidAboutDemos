package com.ssyw.exam.model;

public class ExamBackupsService extends ExamBackupsDao {

}
