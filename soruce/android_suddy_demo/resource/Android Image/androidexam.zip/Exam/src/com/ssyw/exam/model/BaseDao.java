package com.ssyw.exam.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;

@SuppressLint("NewApi")
/**
 * @author sxenon
 * Base CURD
 */
/**
 * 为方便起见，对数据库的设计做如下要求
 * 1、不能有null:TEXT 的用"", INTEGER或REAL 的用0
 * 2、Dao层：Cursor与 ArrayList配合使用 /Service层只能调用Dao返回的ArrayList或 Map
 */
public class BaseDao {
	private SQLiteDatabase db;

	private SQLiteDatabase openOrGetDB(Context context) {
		return DBHelper.openOrGetDB(context);
	}

	// find
	/**
	 * 
	 * @param context
	 * @param distinct
	 * @param table
	 * @param showColumns
	 *            null:"*"
	 * @param whereClause
	 * @param groupBy
	 * @param having
	 * @param orderBy
	 * @param limit
	 * @return
	 */
	protected Cursor getCursorByQuery(Context context, boolean distinct,
			String table, String[] showColumns, String whereClause,
			String groupBy, String having, String orderBy, String limit) {
		db = openOrGetDB(context);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT ");
		if (distinct) {
			sql.append(" DISTINCT ");
		}

		if (showColumns == null) {
			sql.append(" * ");
		} else {
			appendColumns(sql, showColumns);
		}
		sql.append(" FROM ");
		sql.append(table);

		appendWhereClause(sql, whereClause);

		if (groupBy != null) {
			sql.append(" GROUP BY ");
			sql.append(groupBy);
			if (having != null) {
				sql.append(" HAVING ");
				sql.append(having);
			}
		}

		if (orderBy != null) {
			sql.append(" ORDER BY ");
			sql.append(orderBy);
			
		}
		
		if (limit != null) {
			sql.append(" LIMIT ");
			sql.append(limit);
		}
		sql.append(";");
		return db.rawQuery(sql.toString(), null);
	}

	// 下面几个配合getCursorByQuery使用
	protected ArrayList<Map<String, Object>> getMapListByCursor(Cursor cursor) {
		ArrayList<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
		String[] columnNames = cursor.getColumnNames();
		while (cursor.moveToNext()) {
			Map<String, Object> map = new HashMap<String, Object>();
			for (int i = 0; i < columnNames.length; i++) {
				switch (cursor.getType(i)) {
				case Cursor.FIELD_TYPE_BLOB:
					map.put(columnNames[i], cursor.getBlob(i));
					break;
				case Cursor.FIELD_TYPE_FLOAT:
					map.put(columnNames[i], cursor.getFloat(i));
					break;
				case Cursor.FIELD_TYPE_INTEGER:
					map.put(columnNames[i], cursor.getInt(i));
					break;
				case Cursor.FIELD_TYPE_STRING:
					map.put(columnNames[i], cursor.getString(i));
					break;
				case Cursor.FIELD_TYPE_NULL:
					map.put(columnNames[i], null);
					break;
				default:
					Log.e("getEntryListByCursor", "unKnown type");
					break;
				}
			}
			mapList.add(map);
		}
		cursor.close();
		return mapList;
	}

	/**
	 * @param cursor
	 * @return Map 单个
	 */
	protected Map<String, Object> getMapByCursor(Cursor cursor) {
		ArrayList<Map<String, Object>> mapList = getMapListByCursor(cursor);
		if (mapList.isEmpty()) {
			return null;
		} else {
			return mapList.get(0);
		}
	}

	/**
	 * @param cursor
	 * @return List 单列
	 */
	protected ArrayList<String> getStringListByCursor(Cursor cursor) {
		ArrayList<String> stringList = new ArrayList<String>();
		while (cursor.moveToNext()) {
			stringList.add(cursor.getString(0));
		}
		cursor.close();
		return stringList;
	}

	protected ArrayList<Integer> getIntegerListByCursor(Cursor cursor) {
		ArrayList<Integer> integerList = new ArrayList<Integer>();
		while (cursor.moveToNext()) {
			integerList.add(cursor.getInt(0));
		}
		cursor.close();
		return integerList;
	}

	protected ArrayList<Float> getFloatListByCursor(Cursor cursor) {
		ArrayList<Float> floatList = new ArrayList<Float>();
		while (cursor.moveToNext()) {
			floatList.add(cursor.getFloat(0));
		}
		cursor.close();
		return floatList;
	}

	protected ArrayList<byte[]> getBlobListByCursor(Cursor cursor) {
		ArrayList<byte[]> blobList = new ArrayList<byte[]>();
		while (cursor.moveToNext()) {
			blobList.add(cursor.getBlob(0));
		}
		cursor.close();
		return blobList;
	}

	// add
	protected long add(Context context, String table, ContentValues values) {
		db = openOrGetDB(context);
		return db.insert(table, null, values);
	}

	// update
	/**
	 * 
	 * @param context
	 * @param table
	 * @param setValues
	 *            不用加"="，需要改几项就写几项
	 * @param whereClause
	 * @return 1 success/-1 fail
	 */
	protected int update(Context context, String table,
			ContentValues setValues, String whereClause) {
		db = openOrGetDB(context);
		StringBuilder sql = new StringBuilder();
		sql.append("UPDATE " + table + " SET ");
		appendSetValues(sql, setValues);
		appendWhereClause(sql, whereClause);
		sql.append(";");
		try {
			db.execSQL(sql.toString());
			return 1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}

	// delete
	/**
	 * 
	 * @param context
	 * @param table
	 * @param whereClause
	 * @return 1 success/-1 fail
	 */
	protected int delete(Context context, String table, String whereClause) {
		db = openOrGetDB(context);
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE FROM " + table);
		appendWhereClause(sql, whereClause);
		sql.append(";");
		try {
			db.execSQL(sql.toString());
			return 1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}

	protected void createTable(Context context, String table, String value) {
		db = openOrGetDB(context);
		StringBuilder sql = new StringBuilder();
		sql.append("CREATE TABLE " + table + "(" + value + ");");
		db.execSQL(sql.toString());
	}

	protected boolean checkTableExist(Context context, String table) {
		db = openOrGetDB(context);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='"
				+ table + "';");
		Cursor cursor = db.rawQuery(sql.toString(), null);
		if (cursor.getInt(cursor.getColumnIndex("count(*)")) == 1)
			return true;
		else
			return false;
	}

	protected void dropTable(Context context, String table) {
		db = openOrGetDB(context);
		StringBuilder sql = new StringBuilder();
		sql.append("DROP TABLE " + table + ";");
		db.execSQL(sql.toString());
	}

	private void appendColumns(StringBuilder s, String[] columns) {
		int n = columns.length;

		for (int i = 0; i < n; i++) {
			String column = columns[i];

			if (column != null) {
				if (i > 0) {
					s.append(", ");
				}
				s.append(column);
			}
		}
		s.append(' ');
	}

	private void appendWhereClause(StringBuilder s, String whereClause) {
		if (!TextUtils.isEmpty(whereClause)) {
			s.append(" WHERE ");
			s.append(whereClause);

		}
	}

	private void appendSetValues(StringBuilder s, ContentValues setValues) {
		for (String colName : setValues.keySet()) {
			s.append(colName + "=");
			Object value = setValues.get(colName);
			if (value instanceof String) {
				s.append("'" + value + "'");
			} else {
				s.append(value);
			}
			s.append(",");
		}
		// 删除最后一个 ","
		s.deleteCharAt(s.length() - 1);
	}

	protected String getWhereClause(ArrayList<String> whereList) {
		StringBuilder whereClause = new StringBuilder();
		whereClause.append("(");
		for (String subWhere : whereList) {
			whereClause.append(subWhere);
			whereClause.append(" ");
		}
		whereClause.append(") ");
		return whereClause.toString();
	}

}
