package com.ssyw.exam.controller;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;

import com.ssyw.exam.R;
import com.ssyw.exam.widget.RoundedListViewAdapter;

public class ShareSettingController {
	public RoundedListViewAdapter getGroupAdapter(Context context) {
		List<String> titleDatas = new ArrayList<String>();
		List<String> promptDatas = new ArrayList<String>();
		titleDatas.add(getStringById(context, R.string.sina_weibo));
		titleDatas.add(getStringById(context, R.string.tencent_weibo));
		
		promptDatas.add(getStringById(context, R.string.toBind));
		promptDatas.add(getStringById(context, R.string.toBind));	
		return new RoundedListViewAdapter(titleDatas, promptDatas, context,
				RoundedListViewAdapter.SHARE_GROUP);
	}

	private String getStringById(Context context, int resId) {
		return context.getResources().getString(resId);
	}
}
