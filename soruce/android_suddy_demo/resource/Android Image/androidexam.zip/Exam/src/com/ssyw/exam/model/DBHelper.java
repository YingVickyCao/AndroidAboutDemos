package com.ssyw.exam.model;

import com.ssyw.exam.config.Project;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

@SuppressLint("NewApi")
public class DBHelper extends SQLiteOpenHelper {

	private static final String DBNAME = Project.PROJECT + ".db";
	private static final int VERSION = 4;
	private static SQLiteDatabase db = null;

	static SQLiteDatabase openOrGetDB(Context context) {
		if (db == null) {
			db = new DBHelper(context).getWritableDatabase();
		}
		return db;
	}

	private DBHelper(Context context) {
		this(context, DBNAME, null, VERSION);
	}

	public DBHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub

	}

}
