package com.ssyw.exam;

import com.ssyw.exam.thirdparty.SinaWeiboMethods;
import com.ssyw.exam.thirdparty.TencentWeiboMethods;
import com.ssyw.exam.utility.Utility;
import com.ssyw.exam.utility.WindowHelper;
import com.weibo.sdk.android.Oauth2AccessToken;
import com.weibo.sdk.android.keep.AccessTokenKeeper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;

import android.widget.ImageView;

public class ShareFriendActivity extends Activity {
	private ImageView iv_share_shot;
	private static String tencent_oauthv2 = "tencent_oauthv2";
	private String using;
	private WindowHelper wh;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);// 去掉标题栏

		setContentView(R.layout.activity_share_friend);

		iv_share_shot = (ImageView) findViewById(R.id.iv_share_shot);

		/*
		 * 如果截屏产生的图片太大，则无法通过Intent传递，会产生FAILED BINDER TRANSACTION
		 */
		wh = new WindowHelper(this);
		String pic_path = wh.pic_path;
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = 2;
		Bitmap bm = BitmapFactory.decodeFile(pic_path, options);
		iv_share_shot.setImageBitmap(bm);

		using = getResources().getString(R.string.using);
	}

	public void sendToTencentWeibo(View view) {
		// 过期的事以后再说
		SharedPreferences tencentOauthV2 = this.getSharedPreferences(
				tencent_oauthv2, Context.MODE_APPEND);
		if (TextUtils.isEmpty(tencentOauthV2.getString("AccessToken", ""))) {

			Utility.showToastLong(this,
					getResources().getString(R.string.ask_to_bind));
			Intent intent = new Intent(this, ShareSettingActivity.class);
			startActivity(intent);
		} else {
			Utility.showToastLong(this,
					getResources().getString(R.string.send_weibo_wait));
			TencentWeiboMethods twm = new TencentWeiboMethods();
			twm.sendOneWeibo(this, using, wh.pic_path);
		}
	}

	public void sendToSinaWeibo(View view) {
		Oauth2AccessToken oauth2AccessToken = AccessTokenKeeper
				.readAccessToken(this);
		if (oauth2AccessToken.getToken().equals("")) {

			Utility.showToastLong(this,
					getResources().getString(R.string.ask_to_bind));
			Intent intent = new Intent(this, ShareSettingActivity.class);
			startActivity(intent);
		} else {
			Utility.showToastLong(this,
					getResources().getString(R.string.send_weibo_wait));
			SinaWeiboMethods swm = new SinaWeiboMethods(this);
			swm.sendOneWeibo(this, using, wh.pic_path);
		}
	}

	public void back(View v) {
		finish();
	}
}
