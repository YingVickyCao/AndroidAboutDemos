package com.ssyw.exam2.model;

public class QuestionClassService extends CommonEntryDao {

}
