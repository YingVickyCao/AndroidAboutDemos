package com.ssyw.exam2.model;

public class QuestionTypeService extends CommonEntryDao {

}
