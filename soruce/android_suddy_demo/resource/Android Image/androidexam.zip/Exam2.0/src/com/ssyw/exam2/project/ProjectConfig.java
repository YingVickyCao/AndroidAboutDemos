package com.ssyw.exam2.project;

public class ProjectConfig {
	public static final boolean DEBUG_FLAG=true;
	public static final boolean TOPIC_EXPLAIN_SHOW=false;
	public static final boolean TOPIC_MODE_CHAPTERS_SUPPORT=false;
	public static final boolean TOPIC_MODE_INTENSIFY_SUPPORT=false;
}
