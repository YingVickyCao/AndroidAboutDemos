package com.ssyw.exam2.adapter;

public interface TopicFragmentCallBacks{
	//跳转到第几屏
	public void snapToScreen(int position);
}
