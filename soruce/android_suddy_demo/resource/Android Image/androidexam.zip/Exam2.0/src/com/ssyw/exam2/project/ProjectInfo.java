package com.ssyw.exam2.project;

public class ProjectInfo {
	private static final String NAME="android";
	private static final String TYPE="exam";
	public static final String PROJECT=TYPE+"_"+NAME;
}
